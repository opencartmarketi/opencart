C2C Marketplace 1.0.0 — OpenCart 3.0.5.1 / Codervia
Kurulum ve kapsam: docs/KURULUM.md
Canlı iyzico/PayTR otomatik ödeme entegrasyonu dahil değildir; docs/PAYMENTS.md dosyasını okuyun.
