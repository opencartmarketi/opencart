<?php
/**
 * C2C Marketplace storefront adapter for OpenCart 3.0.5.1 / Codervia.
 * Business rules and ownership checks live in C2c\Marketplace.
 */
class ControllerExtensionModuleC2cMarketplace extends Controller {
    public function productBefore(&$route, &$data, &$code) {
        $data['c2c_product_block'] = '';
        $data['c2c_questions_block'] = '';
        $data['c2c_product_enabled'] = false;
        if (!$this->enabled()) {
            return;
        }
        $product_id = isset($this->request->get['product_id']) ? (int)$this->request->get['product_id'] : 0;
        $seller = $this->marketplace->getSellerForProduct($product_id);
        if (!$seller) {
            return;
        }
        $view = array(
            'seller_name' => $seller['store_name'],
            'seller_url' => $this->url->link('extension/module/c2c_marketplace/store', 'seller_id=' . (int)$seller['seller_id'], true),
            'seller_initial' => utf8_substr($seller['store_name'], 0, 1),
            'brand' => $this->brand(),
            'product_id' => $product_id,
            'questions' => $this->marketplace->getQuestions($product_id),
            'question_action' => $this->url->link('extension/module/c2c_marketplace/question', '', true),
            'csrf' => $this->csrf(),
            'logged' => $this->customer->isLogged(),
            'login' => $this->url->link('extension/module/c2c_marketplace/login', 'product_id=' . $product_id, true),
            'notice' => '',
            'error' => ''
        );
        $view = array_merge($view, $this->socialData((int)$seller['seller_id'], false));
        $view['lead_time'] = isset($seller['lead_time']) ? (int)$seller['lead_time'] : 2;
        if (isset($this->session->data['c2c_question_notice'][$product_id])) {
            $flash = $this->session->data['c2c_question_notice'][$product_id];
            $view['notice'] = isset($flash['notice']) ? $flash['notice'] : '';
            $view['error'] = isset($flash['error']) ? $flash['error'] : '';
            unset($this->session->data['c2c_question_notice'][$product_id]);
        }
        $data['c2c_product_enabled'] = true;
        $data['c2c_product_block'] = $this->load->view('extension/module/c2c_product', $view);
        $data['c2c_questions_block'] = $this->load->view('extension/module/c2c_questions', $view);
    }

    public function headerBefore(&$route, &$data, &$code) {
        $data['c2c_partner_link'] = '';
        if (!$this->enabled()) {
            return;
        }
        // Header's data has already been collected when view/before executes.
        // Append here rather than relying on a later document->addStyle call.
        if (!isset($data['styles']) || !is_array($data['styles'])) {
            $data['styles'] = array();
        }
        $data['styles'][] = array(
            'href' => 'catalog/view/theme/default/stylesheet/c2c_marketplace.css?v=1.0.0',
            'rel' => 'stylesheet',
            'media' => 'screen'
        );
        $host = strtolower(trim((string)$this->config->get('module_c2c_marketplace_partner_host')));
        if ($host && $this->validHostname($host)) {
            $path = parse_url($this->config->get('config_url'), PHP_URL_PATH);
            $data['c2c_partner_link'] = 'https://' . $host . '/' . trim((string)$path, '/') . (trim((string)$path, '/') !== '' ? '/' : '') . 'index.php?route=extension/module/c2c_partner';
        } else {
            $data['c2c_partner_link'] = $this->url->link('extension/module/c2c_partner', '', true);
        }
    }

    public function orderAfter(&$route, &$args, &$output) {
        if ($this->enabled() && (int)$output > 0) {
            $allocation = null;
            $has_campaign_total = false;
            if (isset($args[0]['totals']) && is_array($args[0]['totals'])) {
                foreach ($args[0]['totals'] as $total) {
                    if (isset($total['code'], $total['value']) && $total['code'] === 'c2c_marketplace' && (float)$total['value'] < 0) {
                        $has_campaign_total = true;
                    }
                }
            }
            // Record the allocation only when an actual C2C discount total was stored.
            // Coupons disable product campaigns. Missing allocation is held by the ledger.
            if ($has_campaign_total && empty($this->session->data['coupon']) && isset($args[0]['products'], $args[0]['customer_id']) && is_array($args[0]['products'])) {
                try {
                    $this->load->library('c2c/campaigns');
                    $allocation = $this->campaigns->calculate($args[0]['products'], (int)$args[0]['customer_id']);
                } catch (Exception $e) {
                    $this->log->write('C2C promotion allocation failed; settlement must remain held. Order ID: ' . (int)$output);
                }
            }
            $this->snapshot((int)$output, $allocation);
        }
    }

    public function historyAfter(&$route, &$args, &$output) {
        if ($this->enabled() && isset($args[0]) && (int)$args[0] > 0) {
            $this->snapshot((int)$args[0]);
        }
    }

    public function partnerBefore(&$route, &$args) {
        if (!$this->enabled()) {
            return;
        }
        $host = strtolower(trim((string)$this->config->get('module_c2c_marketplace_partner_host')));
        $request_host = isset($this->request->server['HTTP_HOST']) ? strtolower($this->request->server['HTTP_HOST']) : '';
        // Compare the complete authority. Unknown hosts/ports never cause redirects.
        if (!$host || !$this->validHostname($host) || $host !== $request_host) {
            return;
        }
        $path = parse_url($this->config->get('config_url'), PHP_URL_PATH);
        $base = '/' . trim((string)$path, '/');
        $base = rtrim($base, '/') . '/';
        $this->response->redirect($base . 'index.php?route=extension/module/c2c_partner');
    }

    public function store() {
        if (!$this->enabled()) {
            return $this->notFound();
        }
        $seller_id = isset($this->request->get['seller_id']) ? (int)$this->request->get['seller_id'] : 0;
        if (!$seller_id && isset($this->request->get['slug']) && is_string($this->request->get['slug']) && preg_match('/^[a-z0-9-]{3,64}$/D', $this->request->get['slug'])) {
            $query = $this->db->query("SELECT seller_id FROM `" . DB_PREFIX . "c2c_seller` WHERE slug = '" . $this->db->escape($this->request->get['slug']) . "' AND status = 'approved' LIMIT 1");
            $seller_id = $query->num_rows ? (int)$query->row['seller_id'] : 0;
        }
        $seller = $this->marketplace->getSeller($seller_id, true);
        if (!$seller) {
            return $this->notFound();
        }
        $page = isset($this->request->get['page']) ? max(1, min(100000, (int)$this->request->get['page'])) : 1;
        $limit = 24;
        $total = $this->marketplace->countPublicProducts($seller_id);
        $this->document->setTitle(htmlspecialchars($seller['store_name'] . ' | ' . $this->brand(), ENT_QUOTES, 'UTF-8'));
        $this->document->setDescription(htmlspecialchars(utf8_substr(strip_tags($seller['description']), 0, 160), ENT_QUOTES, 'UTF-8'));
        $this->document->addLink($this->url->link('extension/module/c2c_marketplace/store', 'seller_id=' . $seller_id, true), 'canonical');
        $this->load->model('catalog/product');
        $this->load->model('tool/image');
        $data = array(
            'store_name' => $seller['store_name'],
            'store_description' => $seller['description'],
            'store_initial' => utf8_substr($seller['store_name'], 0, 1),
            'brand' => $this->brand(),
            'total' => (int)$total,
            'products' => array(),
            'home' => $this->url->link('common/home'),
            'catalog_url' => $this->url->link('product/search'),
            'page' => $page,
            'pages' => max(1, (int)ceil($total / $limit)),
            'previous' => $page > 1 ? $this->url->link('extension/module/c2c_marketplace/store', 'seller_id=' . $seller_id . '&page=' . ($page - 1), true) : '',
            'next' => $page * $limit < $total ? $this->url->link('extension/module/c2c_marketplace/store', 'seller_id=' . $seller_id . '&page=' . ($page + 1), true) : ''
        );
        foreach ($this->marketplace->getPublicProducts($seller_id, ($page - 1) * $limit, $limit) as $row) {
            // Use native catalog pricing, tax and customer-group rules.
            $product = $this->model_catalog_product->getProduct((int)$row['product_id']);
            if (!$product) {
                continue;
            }
            $image = 'placeholder.png';
            if ($product['image'] && is_file(DIR_IMAGE . $product['image'])) {
                $image = $product['image'];
            }
            $price = false;
            $special = false;
            if ($this->customer->isLogged() || !$this->config->get('config_customer_price')) {
                $price = html_entity_decode($this->currency->format($this->tax->calculate($product['price'], $product['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']), ENT_QUOTES, 'UTF-8');
                if ($product['special'] !== null && (float)$product['special'] >= 0 && (string)$product['special'] !== '') {
                    $special = html_entity_decode($this->currency->format($this->tax->calculate($product['special'], $product['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']), ENT_QUOTES, 'UTF-8');
                }
            }
            $data['products'][] = array(
                'product_id' => (int)$product['product_id'],
                'name' => html_entity_decode($product['name'], ENT_QUOTES, 'UTF-8'),
                'href' => $this->url->link('product/product', 'product_id=' . (int)$product['product_id']),
                'image' => $this->model_tool_image->resize($image, 400, 400),
                'price' => $price,
                'special' => $special,
                'rating' => (float)$product['rating'],
                'reviews' => (int)$product['reviews'],
                'review_status' => (bool)$this->config->get('config_review_status'),
                'in_stock' => (int)$product['quantity'] > 0,
                'lead_time' => isset($row['lead_time']) ? (int)$row['lead_time'] : 2
            );
        }
        $data = array_merge($data, $this->socialData($seller_id, true));
        $data['social_block'] = $this->load->view('extension/module/c2c_social', $data);
        $data['footer'] = $this->load->controller('common/footer');
        $data['header'] = $this->load->controller('common/header');
        $this->response->setOutput($this->load->view('extension/module/c2c_store', $data));
    }

    public function login() {
        if (!$this->enabled()) {
            return $this->notFound();
        }
        $product_id = isset($this->request->get['product_id']) ? (int)$this->request->get['product_id'] : 0;
        $seller_id = isset($this->request->get['seller_id']) ? (int)$this->request->get['seller_id'] : 0;
        // Redirect destination is generated locally, never accepted from the browser.
        if ($product_id && $this->marketplace->getSellerForProduct($product_id)) {
            $destination = $this->url->link('product/product', 'product_id=' . $product_id, true) . '#c2c-questions';
        } elseif ($seller_id && $this->marketplace->getSeller($seller_id, true)) {
            $destination = $this->url->link('extension/module/c2c_marketplace/store', 'seller_id=' . $seller_id, true) . '#c2c-store-community';
        } else {
            return $this->notFound();
        }
        $this->session->data['redirect'] = $destination;
        $this->response->redirect($this->url->link('account/login', '', true));
    }

    public function question() {
        if (!$this->enabled()) {
            return $this->notFound();
        }
        if (!isset($this->request->server['REQUEST_METHOD']) || $this->request->server['REQUEST_METHOD'] !== 'POST') {
            $this->response->addHeader('HTTP/1.1 405 Method Not Allowed');
            $this->response->addHeader('Allow: POST');
            $this->response->setOutput('Bu işlem POST isteği gerektirir.');
            return;
        }
        $product_id = isset($this->request->post['product_id']) ? (int)$this->request->post['product_id'] : 0;
        if (!$this->marketplace->getSellerForProduct($product_id)) {
            return $this->notFound();
        }
        $notice = '';
        $error = '';
        $token = isset($this->request->post['csrf']) && is_string($this->request->post['csrf']) ? $this->request->post['csrf'] : '';
        if (!$this->customer->isLogged()) {
            $error = 'Soru göndermek için hesabınıza giriş yapın.';
        } elseif (!$token || !hash_equals($this->csrf(), $token)) {
            $error = 'Oturum doğrulanamadı. Sayfayı yenileyip yeniden deneyin.';
        } else {
            try {
                $question = isset($this->request->post['question']) && is_string($this->request->post['question']) ? $this->request->post['question'] : '';
                $this->marketplace->askQuestion($product_id, (int)$this->customer->getId(), $question);
                $notice = 'Sorunuz mağazaya iletildi. Yanıtlandıktan sonra bu sayfada yayınlanır.';
            } catch (InvalidArgumentException $e) {
                $error = $e->getMessage();
            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Exception $e) {
                $this->log->write('C2C question submission failed. Product ID: ' . $product_id);
                $error = 'Sorunuz şu anda kaydedilemedi. Lütfen daha sonra yeniden deneyin.';
            }
        }
        $this->session->data['c2c_question_notice'][$product_id] = array('notice' => $notice, 'error' => $error);
        $this->response->redirect($this->url->link('product/product', 'product_id=' . $product_id, true) . '#c2c-questions');
    }

    public function follow() {
        return $this->socialWrite('follow');
    }

    public function review() {
        return $this->socialWrite('review');
    }

    public function storeQuestion() {
        return $this->socialWrite('question');
    }

    private function socialData($seller_id, $full) {
        $this->load->library('c2c/social');
        $this->load->library('c2c/campaigns');
        $customer_id = $this->customer->isLogged() ? (int)$this->customer->getId() : 0;
        $owner = $customer_id ? $this->marketplace->getSellerByCustomer($customer_id) : array();
        $rating = $this->social->getRating($seller_id);
        $campaigns = array();
        $follower_offer = '';
        foreach ($this->campaigns->getCampaigns($seller_id, true) as $campaign) {
            $type = $campaign['type'];
            $label = '';
            $detail = '';
            if (($type === 'buy3pay2' || $type === 'follower_percent') && !$this->config->get('total_c2c_marketplace_status')) {
                continue;
            }
            if (($type === 'shipping_free' || $type === 'shipping_threshold') && !$this->config->get('shipping_c2c_marketplace_status')) {
                continue;
            }
            if ($type === 'buy3pay2') {
                $label = '3 al, 2 öde';
                $detail = 'Bu mağazanın ürünlerinden her 3 adette en ucuz ürün tutarı indirilir.';
            } elseif ($type === 'follower_percent') {
                $percent = rtrim(rtrim(number_format((float)$campaign['value'], 2, ',', ''), '0'), ',');
                $label = 'Takipçilere %' . $percent . ' indirim';
                $detail = 'Hesabınızla giriş yapıp bu mağazayı takip ettiğiniz sürece geçerlidir.';
                $follower_offer = '%' . $percent;
            } elseif ($type === 'shipping_free') {
                $label = 'Mağaza bazlı kargo ücretsiz';
                $detail = 'Ödeme adımında Mağaza bazlı kargo yöntemi seçildiğinde bu mağazanın kargo bedeli alınmaz.';
            } elseif ($type === 'shipping_threshold') {
                $threshold = html_entity_decode($this->currency->format((float)$campaign['threshold'], $this->session->data['currency']), ENT_QUOTES, 'UTF-8');
                $label = $threshold . ' ve üzeri ürün tutarında kargo ücretsiz';
                $detail = 'Bu mağazanın kampanya öncesi, vergi ve kargo hariç ürün tutarı için; Mağaza bazlı kargo yöntemi seçildiğinde geçerlidir.';
            }
            if ($label !== '') {
                $campaigns[] = array('name' => $campaign['name'], 'label' => $label, 'detail' => $detail, 'type' => $type, 'date_end' => $campaign['date_end']);
            }
        }
        $data = array(
            'seller_id' => (int)$seller_id,
            'follower_count' => (int)$this->social->getFollowerCount($seller_id),
            'following' => $customer_id ? (bool)$this->social->isFollowing($seller_id, $customer_id) : false,
            'store_rating' => isset($rating['rating']) ? (float)$rating['rating'] : 0,
            'store_review_count' => isset($rating['total']) ? (int)$rating['total'] : 0,
            'social_logged' => (bool)$customer_id,
            'social_is_owner' => $owner && (int)$owner['seller_id'] === (int)$seller_id,
            'social_login' => $this->url->link('extension/module/c2c_marketplace/login', 'seller_id=' . (int)$seller_id, true),
            'follow_action' => $this->url->link('extension/module/c2c_marketplace/follow', '', true),
            'review_action' => $this->url->link('extension/module/c2c_marketplace/review', '', true),
            'store_question_action' => $this->url->link('extension/module/c2c_marketplace/storeQuestion', '', true),
            'campaigns' => $campaigns,
            'follower_offer' => $follower_offer,
            'csrf' => $this->csrf(),
            'social_notice' => '',
            'social_error' => ''
        );
        if (isset($this->session->data['c2c_store_notice'][$seller_id])) {
            $flash = $this->session->data['c2c_store_notice'][$seller_id];
            $data['social_notice'] = isset($flash['notice']) ? $flash['notice'] : '';
            $data['social_error'] = isset($flash['error']) ? $flash['error'] : '';
            unset($this->session->data['c2c_store_notice'][$seller_id]);
        }
        if ($full) {
            $data['store_reviews'] = $this->social->getReviews($seller_id, 0, 20);
            $data['store_questions'] = $this->social->getStoreQuestions($seller_id, true, 0, 30);
            $data['reviewable_orders'] = $customer_id && !$data['social_is_owner'] ? $this->social->getReviewableOrders($seller_id, $customer_id) : array();
        }
        return $data;
    }

    private function socialWrite($kind) {
        if (!$this->enabled()) {
            return $this->notFound();
        }
        if (!isset($this->request->server['REQUEST_METHOD']) || $this->request->server['REQUEST_METHOD'] !== 'POST') {
            $this->response->addHeader('HTTP/1.1 405 Method Not Allowed');
            $this->response->addHeader('Allow: POST');
            $this->response->setOutput('Bu işlem POST isteği gerektirir.');
            return;
        }
        $seller_id = isset($this->request->post['seller_id']) ? (int)$this->request->post['seller_id'] : 0;
        if (!$this->marketplace->getSeller($seller_id, true)) {
            return $this->notFound();
        }
        $notice = '';
        $error = '';
        $token = isset($this->request->post['csrf']) && is_string($this->request->post['csrf']) ? $this->request->post['csrf'] : '';
        if (!$this->customer->isLogged()) {
            $error = 'Bu işlem için hesabınıza giriş yapın.';
        } elseif (!$token || !hash_equals($this->csrf(), $token)) {
            $error = 'Oturum doğrulanamadı. Sayfayı yenileyip yeniden deneyin.';
        } else {
            try {
                $this->load->library('c2c/social');
                $customer_id = (int)$this->customer->getId();
                if ($kind === 'follow') {
                    $follow = isset($this->request->post['follow']) && is_string($this->request->post['follow']) ? $this->request->post['follow'] : '';
                    if ($follow !== '1' && $follow !== '0') {
                        throw new InvalidArgumentException('Geçersiz takip işlemi.');
                    }
                    $this->social->follow($seller_id, $customer_id, $follow === '1');
                    $notice = $follow === '1' ? 'Mağazayı takip etmeye başladınız. Geçerli takipçi kampanyaları sepetinizde uygulanır.' : 'Mağazayı takipten çıktınız.';
                } elseif ($kind === 'review') {
                    $this->social->addReview($seller_id, $customer_id, array(
                        'order_id' => isset($this->request->post['order_id']) ? $this->request->post['order_id'] : '',
                        'rating' => isset($this->request->post['rating']) ? $this->request->post['rating'] : '',
                        'text' => isset($this->request->post['text']) ? $this->request->post['text'] : ''
                    ));
                    $notice = 'Doğrulanmış alışveriş değerlendirmeniz yayınlandı. Teşekkür ederiz.';
                } elseif ($kind === 'question') {
                    $question = isset($this->request->post['question']) && is_string($this->request->post['question']) ? $this->request->post['question'] : '';
                    $this->social->askStoreQuestion($seller_id, $customer_id, $question);
                    $notice = 'Sorunuz mağazaya iletildi. Yanıtlandığında burada yayınlanır.';
                }
            } catch (InvalidArgumentException $e) {
                $error = $e->getMessage();
            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Exception $e) {
                $this->log->write('C2C store social action failed. Seller ID: ' . $seller_id);
                $error = 'İşleminiz şu anda kaydedilemedi. Lütfen daha sonra yeniden deneyin.';
            }
        }
        $this->session->data['c2c_store_notice'][$seller_id] = array('notice' => $notice, 'error' => $error);
        $destination = $this->url->link('extension/module/c2c_marketplace/store', 'seller_id=' . $seller_id, true) . '#c2c-store-community';
        // A product follow CTA may return only to this approved seller's own product.
        $return_product_id = isset($this->request->post['return_product_id']) ? (int)$this->request->post['return_product_id'] : 0;
        if ($kind === 'follow' && $return_product_id) {
            $product_seller = $this->marketplace->getSellerForProduct($return_product_id);
            if ($product_seller && (int)$product_seller['seller_id'] === $seller_id) {
                $destination = $this->url->link('product/product', 'product_id=' . $return_product_id, true) . '#c2c-merchant';
            }
        }
        $this->response->redirect($destination);
    }

    private function enabled() {
        $this->load->library('c2c/marketplace');
        return $this->marketplace->isEnabled();
    }

    private function brand() {
        $brand = trim((string)$this->config->get('module_c2c_marketplace_brand'));
        return $brand !== '' ? $brand : 'Pazar Yeri';
    }

    private function csrf() {
        if (empty($this->session->data['c2c_csrf']) || !is_string($this->session->data['c2c_csrf'])) {
            $this->session->data['c2c_csrf'] = bin2hex(random_bytes(32));
        }
        return $this->session->data['c2c_csrf'];
    }

    private function validHostname($host) {
        return strlen($host) <= 253 && strpos($host, '.') !== false && (bool)filter_var($host, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME);
    }

    private function snapshot($order_id, $allocation = null) {
        try {
            $this->marketplace->recordOrder($order_id, $allocation);
        } catch (Exception $e) {
            // Never turn an already-created order into a failed checkout response.
            // The status-history event retries idempotently. Log no buyer data.
            $this->log->write('C2C order snapshot failed; inspect before settlement. Order ID: ' . (int)$order_id);
        }
    }

    private function notFound() {
        $this->response->addHeader('HTTP/1.1 404 Not Found');
        $this->load->controller('error/not_found');
    }
}
