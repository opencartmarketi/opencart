<?php
/** C2C Partner workspace. Uses OpenCart customer authentication; no shared-domain cookies. */
class ControllerExtensionModuleC2cPartner extends Controller {
    private $seller = array();

    public function index() {
        if (!$this->boot(false)) { return; }
        $view = isset($this->request->get['view']) && is_string($this->request->get['view']) ? $this->request->get['view'] : 'dashboard';
        $allowed = array('dashboard', 'products', 'product', 'orders', 'order', 'questions', 'profile', 'ledger', 'campaigns', 'returns', 'return');
        if (!in_array($view, $allowed, true)) { $view = 'dashboard'; }
        $logged = (bool)$this->customer->isLogged();
        if (!$logged) { $view = 'login'; }
        elseif (!$this->seller) { $view = 'application'; }
        elseif ($this->seller['status'] !== 'approved' && $view !== 'profile') { $view = 'pending'; }
        $page = isset($this->request->get['page']) ? max(1, min(100000, (int)$this->request->get['page'])) : 1;
        $limit = 20;
        $data = array('t' => $this->load->language('extension/module/c2c_partner'), 'view' => $view, 'seller' => $this->seller,
            'logged' => $logged, 'csrf' => $this->token(), 'brand' => $this->brand(), 'base' => $this->base(),
            'stylesheet' => $this->base() . 'catalog/view/theme/default/stylesheet/c2c_partner.css', 'page' => $page, 'has_next' => false,
            'first_name' => $logged ? $this->customer->getFirstName() : '', 'error' => '', 'success' => '',
            'currency_code' => (string)$this->config->get('config_currency'), 'stats' => array(), 'orders' => array(),
            'products' => array(), 'questions' => array(), 'ledger' => array(), 'order' => array(), 'product' => array(), 'categories' => array(), 'campaigns' => array(), 'campaign' => array(), 'returns' => array(), 'return' => array(), 'followers' => 0, 'social_rating' => array('rating' => 0, 'total' => 0));
        foreach (array('dashboard', 'products', 'product', 'orders', 'questions', 'profile', 'ledger', 'campaigns', 'returns') as $name) {
            $data['url_' . $name] = $this->panelUrl('', array('view' => $name));
        }
        foreach (array('apply', 'profile', 'product', 'upload', 'shipment', 'answer', 'login', 'logout', 'campaign') as $name) { $data['action_' . $name] = $this->panelUrl($name); }
        $data['register'] = $this->publicUrl('account/register');
        $data['forgotten'] = $this->publicUrl('account/forgotten');
        $data['store_url'] = $this->seller ? $this->publicUrl('extension/module/c2c_marketplace/store', 'seller_id=' . (int)$this->seller['seller_id']) : $this->publicUrl('common/home');
        $data['shop_url'] = $this->publicUrl('common/home');
        $data['previous'] = $this->panelUrl('', array('view' => $view, 'page' => max(1, $page - 1)));
        $data['next'] = $this->panelUrl('', array('view' => $view, 'page' => $page + 1));
        foreach (array('error', 'success') as $key) {
            if (isset($this->session->data['c2c_' . $key])) {
                $data[$key] = $this->session->data['c2c_' . $key]; unset($this->session->data['c2c_' . $key]);
            }
        }
        $seller_id = $this->seller ? (int)$this->seller['seller_id'] : 0;
        try {
            if ($seller_id && $this->seller['status'] === 'approved') {
                $data['stats'] = $this->marketplace->getStats($seller_id);
                $this->load->library('c2c/social');
                $data['followers'] = $this->social->getFollowerCount($seller_id);
                $data['social_rating'] = $this->social->getRating($seller_id);
                foreach (array('gross', 'commission', 'net', 'paid', 'balance', 'eligible_net') as $key) {
                    $data['stats'][$key . '_formatted'] = $this->money(isset($data['stats'][$key]) ? $data['stats'][$key] : 0);
                }
                if ($view === 'dashboard' || $view === 'orders') {
                    $data['orders'] = $this->marketplace->getOrders($seller_id, $view === 'dashboard' ? 0 : ($page - 1) * $limit, $view === 'dashboard' ? 5 : $limit + 1);
                    if ($view === 'orders') { $data['has_next'] = count($data['orders']) > $limit; $data['orders'] = array_slice($data['orders'], 0, $limit); }
                    foreach ($data['orders'] as &$order) {
                        $order['href'] = $this->panelUrl('', array('view' => 'order', 'order_id' => (int)$order['order_id']));
                        $order['total_formatted'] = $this->orderMoney($order['total'], $order);
                        $order['net_formatted'] = $this->orderMoney($order['net'], $order);
                    } unset($order);
                }
                if ($view === 'products') {
                    $data['products'] = $this->marketplace->getProducts($seller_id, ($page - 1) * $limit, $limit);
                    $data['has_next'] = $this->marketplace->countProducts($seller_id) > $page * $limit;
                    $this->load->model('tool/image');
                    foreach ($data['products'] as &$product) {
                        $product['href'] = $this->panelUrl('', array('view' => 'product', 'product_id' => (int)$product['product_id']));
                        $product['price_formatted'] = $this->money($product['price']);
                        $product['thumb'] = $this->model_tool_image->resize($product['image'] && is_file(DIR_IMAGE . $product['image']) ? $product['image'] : 'placeholder.png', 80, 80);
                    } unset($product);
                }
                if ($view === 'product') {
                    $id = isset($this->request->get['product_id']) ? (int)$this->request->get['product_id'] : 0;
                    $data['product'] = $id ? $this->marketplace->getProduct($seller_id, $id) : array('product_id' => 0, 'name' => '', 'model' => '', 'description' => '', 'price' => '', 'quantity' => '0', 'category_id' => '', 'image' => '', 'lead_time' => 2);
                    if (!$data['product']) { $this->notFound(); return; }
                    $data['categories'] = $this->marketplace->getCategories();
                }
                if ($view === 'order') {
                    $data['order'] = $this->marketplace->getOrder($seller_id, isset($this->request->get['order_id']) ? (int)$this->request->get['order_id'] : 0);
                    if (!$data['order']) { $this->notFound(); return; }
                    foreach (array('total', 'commission', 'net') as $key) { $data['order'][$key . '_formatted'] = $this->orderMoney($data['order'][$key], $data['order']); }
                    foreach ($data['order']['items'] as &$item) { $item['total_formatted'] = $this->orderMoney($item['total'], $data['order']); } unset($item);
                }
                if ($view === 'questions') {
                    $data['questions'] = $this->marketplace->getSellerQuestions($seller_id);
                    foreach ($data['questions'] as &$question) { $question['kind'] = 'product'; } unset($question);
                    $store_questions = $this->social->getStoreQuestions($seller_id, false, 0, 100);
                    foreach ($store_questions as &$question) { $question['kind'] = 'store'; } unset($question);
                    $data['questions'] = array_merge($data['questions'], $store_questions);
                    usort($data['questions'], function ($a, $b) {
                        $a_answered = !empty($a['answer']); $b_answered = !empty($b['answer']);
                        if ($a_answered !== $b_answered) { return $a_answered ? 1 : -1; }
                        return strcmp($b['date_added'], $a['date_added']);
                    });
                    $data['questions'] = array_slice($data['questions'], 0, 100);
                }
                if ($view === 'returns' || $view === 'return') {
                    $this->load->library('c2c/returns');
                    if ($view === 'returns') {
                        $data['returns'] = $this->returns->getReturns($seller_id, ($page - 1) * $limit, $limit + 1);
                        $data['has_next'] = count($data['returns']) > $limit;
                        $data['returns'] = array_slice($data['returns'], 0, $limit);
                        foreach ($data['returns'] as &$return) { $return['href'] = $this->panelUrl('', array('view' => 'return', 'return_id' => (int)$return['return_id'])); } unset($return);
                    } else {
                        $data['return'] = $this->returns->getReturn($seller_id, isset($this->request->get['return_id']) ? (int)$this->request->get['return_id'] : 0);
                        if (!$data['return']) { $this->notFound(); return; }
                    }
                }
                if ($view === 'campaigns') {
                    $this->load->library('c2c/campaigns');
                    $data['campaigns'] = $this->campaigns->getCampaigns($seller_id);
                    $data['campaign'] = array('campaign_id' => 0, 'name' => '', 'type' => 'buy3pay2', 'value' => '0', 'threshold' => '0', 'status' => 1, 'date_start' => date('Y-m-d'), 'date_end' => date('Y-m-d', strtotime('+30 days')));
                    $selected = isset($this->request->get['campaign_id']) ? (int)$this->request->get['campaign_id'] : 0;
                    $found = !$selected;
                    foreach ($data['campaigns'] as &$campaign) {
                        $campaign['href'] = $this->panelUrl('', array('view' => 'campaigns', 'campaign_id' => (int)$campaign['campaign_id']));
                        $campaign['threshold_formatted'] = $this->money($campaign['threshold']);
                        if ($selected === (int)$campaign['campaign_id']) { $data['campaign'] = $campaign; $found = true; }
                    } unset($campaign);
                    if (!$found) { $this->notFound(); return; }
                }
                if ($view === 'ledger') {
                    $data['ledger'] = $this->marketplace->getLedger($seller_id, ($page - 1) * $limit, $limit + 1);
                    $data['has_next'] = count($data['ledger']) > $limit; $data['ledger'] = array_slice($data['ledger'], 0, $limit);
                    foreach ($data['ledger'] as &$entry) { $entry['amount_formatted'] = html_entity_decode($this->currency->format((float)$entry['amount'], isset($entry['currency_code']) ? $entry['currency_code'] : $this->config->get('config_currency'), 1), ENT_QUOTES, 'UTF-8'); } unset($entry);
                }
            }
        } catch (\InvalidArgumentException $e) { $data['error'] = $e->getMessage(); }
        catch (\RuntimeException $e) { $data['error'] = $e->getMessage(); }
        catch (\Exception $e) { $data['error'] = $this->language->get('error_generic'); $this->log->write('C2C partner view failed: ' . get_class($e)); }
        if (!empty($this->session->data['c2c_form'])) {
            $form = $this->session->data['c2c_form']; unset($this->session->data['c2c_form']);
            if ($view === 'product') { $data['product'] = array_merge($data['product'], $form); }
            elseif ($view === 'campaigns') { $data['campaign'] = array_merge($data['campaign'], $form); }
            elseif ($view === 'profile' || $view === 'application') { $data['seller'] = array_merge($data['seller'], $form); }
        }
        $this->response->addHeader('Cache-Control: no-store, private');
        $this->response->addHeader('X-Content-Type-Options: nosniff');
        $this->response->addHeader('Referrer-Policy: same-origin');
        $this->response->addHeader('X-Frame-Options: SAMEORIGIN');
        $this->response->setOutput($this->load->view('extension/module/c2c_partner', $data));
    }

    public function login() {
        if (!$this->boot(false) || !$this->validPost()) { return; }
        $this->load->model('account/customer');
        $email = trim($this->text('email')); $password = $this->text('password');
        $attempt = $this->model_account_customer->getLoginAttempts($email);
        $limit = (int)$this->config->get('config_login_attempts'); if ($limit < 1) { $limit = 5; }
        if (strlen($email) > 254 || strlen($password) > 1024 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->flash('error', $this->language->get('error_login'));
        } elseif ($attempt && (int)$attempt['total'] >= $limit && strtotime($attempt['date_modified']) > time() - 3600) {
            $this->flash('error', $this->language->get('error_attempts'));
        } elseif (!$this->customer->login($email, $password)) {
            $this->model_account_customer->addLoginAttempt($email); $this->flash('error', $this->language->get('error_login'));
        } else {
            $this->model_account_customer->deleteLoginAttempts($email);
            $this->forgetRemember(); $this->rotateSession();
            unset($this->session->data['c2c_csrf']);
        }
        $this->response->redirect($this->panelUrl());
    }

    public function logout() {
        if (!$this->boot(true) || !$this->validPost()) { return; }
        $this->forgetRemember(); $this->customer->logout(); $this->rotateSession(); unset($this->session->data['c2c_csrf']);
        $this->response->redirect($this->panelUrl());
    }

    public function apply() {
        $this->write('application', false, function () {
            $data = $this->fields(array('store_name', 'slug', 'description', 'phone', 'legal_name'));
            $this->marketplace->apply($this->customer->getId(), $data);
        });
    }

    public function profile() {
        $this->write('profile', false, function () {
            if (!$this->seller) { throw new \InvalidArgumentException($this->language->get('error_seller')); }
            $this->marketplace->updateSeller((int)$this->seller['seller_id'], $this->fields(array('store_name', 'description', 'phone', 'legal_name')));
        });
    }

    public function product() {
        $id = isset($this->request->post['product_id']) ? (int)$this->request->post['product_id'] : 0;
        $this->write('product', true, function () use ($id) {
            $data = $this->fields(array('name', 'model', 'description', 'price', 'quantity', 'category_id', 'image', 'lead_time'));
            if ($id && !$this->marketplace->getProduct((int)$this->seller['seller_id'], $id)) { throw new \InvalidArgumentException($this->language->get('error_product')); }
            $uploaded = '';
            if (isset($this->request->files['product_image']) && (int)$this->request->files['product_image']['error'] !== UPLOAD_ERR_NO_FILE) {
                $uploaded = $data['image'] = $this->storeUpload($this->request->files['product_image']);
            }
            try { $this->marketplace->saveProduct((int)$this->seller['seller_id'], $data, $id); }
            catch (\Exception $e) { if ($uploaded && is_file(DIR_IMAGE . $uploaded)) { unlink(DIR_IMAGE . $uploaded); } throw $e; }
        }, array('product_id' => $id), 'products');
    }

    public function upload() {
        if (!$this->boot(true) || !$this->validPost(true)) { return; }
        $json = array();
        try {
            $this->requireApproved();
            if (empty($this->request->files['file'])) { throw new \InvalidArgumentException($this->language->get('error_image')); }
            $json['image'] = $this->storeUpload($this->request->files['file']);
        } catch (\InvalidArgumentException $e) { $json['error'] = $e->getMessage(); }
        catch (\Exception $e) { $json['error'] = $this->language->get('error_generic'); }
        $this->response->addHeader('Content-Type: application/json');
        $this->response->addHeader('X-Content-Type-Options: nosniff');
        $this->response->setOutput(json_encode($json));
    }

    public function shipment() {
        $id = isset($this->request->post['order_id']) ? (int)$this->request->post['order_id'] : 0;
        $this->write('order', true, function () use ($id) {
            $this->marketplace->saveShipment((int)$this->seller['seller_id'], $id, $this->text('shipping_company'), $this->text('tracking_number'));
        }, array('order_id' => $id));
    }

    public function answer() {
        $this->write('questions', true, function () {
            $kind = $this->text('kind');
            $question_id = isset($this->request->post['question_id']) ? (int)$this->request->post['question_id'] : 0;
            if ($kind === 'store') {
                $this->load->library('c2c/social');
                $this->social->answerStoreQuestion((int)$this->seller['seller_id'], $question_id, $this->text('answer'));
            } elseif ($kind === 'product' || $kind === '') {
                $this->marketplace->answerQuestion((int)$this->seller['seller_id'], $question_id, $this->text('answer'));
            } else { throw new \InvalidArgumentException($this->language->get('error_question_kind')); }
        });
    }

    public function campaign() {
        $id = isset($this->request->post['campaign_id']) ? (int)$this->request->post['campaign_id'] : 0;
        $this->write('campaigns', true, function () use ($id) {
            $this->load->library('c2c/campaigns');
            $data = $this->fields(array('name', 'type', 'value', 'threshold', 'date_start', 'date_end'));
            $data['status'] = $this->text('status') === '1' ? 1 : 0;
            $this->campaigns->saveCampaign((int)$this->seller['seller_id'], $data, $id);
        }, array('campaign_id' => $id), 'campaigns');
    }

    private function write($view, $approved, $callback, $args = array(), $success_view = '') {
        if (!$this->boot(true) || !$this->validPost()) { return; }
        try {
            if ($approved) { $this->requireApproved(); }
            $callback(); $this->flash('success', $this->language->get('text_saved'));
            unset($this->session->data['c2c_form']);
            $this->response->redirect($this->panelUrl('', array('view' => $success_view ? $success_view : $view) + $args)); return;
        } catch (\InvalidArgumentException $e) { $this->flash('error', $e->getMessage()); }
        catch (\RuntimeException $e) { $this->flash('error', $e->getMessage()); }
        catch (\Exception $e) { $this->flash('error', $this->language->get('error_generic')); $this->log->write('C2C partner action failed: ' . get_class($e)); }
        if (in_array($view, array('product', 'profile', 'application', 'campaigns'), true)) {
            $keys = $view === 'product' ? array('name', 'model', 'description', 'price', 'quantity', 'category_id', 'image', 'lead_time') : array('store_name', 'slug', 'description', 'phone', 'legal_name');
            if ($view === 'campaigns') { $keys = array('name', 'type', 'value', 'threshold', 'date_start', 'date_end', 'status'); }
            $this->session->data['c2c_form'] = $this->fields($keys);
        }
        $this->response->redirect($this->panelUrl('', array('view' => $view) + $args));
    }

    private function boot($auth) {
        $this->load->language('extension/module/c2c_partner');
        $this->load->library('c2c/marketplace');
        if (!$this->marketplace->isEnabled()) { $this->notFound(); return false; }
        if ($auth && !$this->customer->isLogged()) {
            $this->flash('error', $this->language->get('error_auth'));
            $this->response->redirect($this->panelUrl()); return false;
        }
        if ($this->customer->isLogged()) { $this->seller = $this->marketplace->getSellerByCustomer($this->customer->getId()); }
        return true;
    }

    private function validPost($json = false) {
        if (!isset($this->request->server['REQUEST_METHOD']) || $this->request->server['REQUEST_METHOD'] !== 'POST') {
            $this->response->addHeader('HTTP/1.1 405 Method Not Allowed'); $this->response->addHeader('Allow: POST');
            $this->response->setOutput($json ? json_encode(array('error' => 'POST required')) : 'POST required'); return false;
        }
        $token = $this->text('csrf');
        if (!isset($this->session->data['c2c_csrf']) || !$token || !hash_equals($this->session->data['c2c_csrf'], $token)) {
            $this->response->addHeader('HTTP/1.1 403 Forbidden');
            if ($json) { $this->response->addHeader('Content-Type: application/json'); }
            $this->response->setOutput($json ? json_encode(array('error' => $this->language->get('error_csrf'))) : $this->language->get('error_csrf')); return false;
        }
        return true;
    }

    private function requireApproved() {
        if (!$this->seller || $this->seller['status'] !== 'approved') { throw new \InvalidArgumentException($this->language->get('error_seller')); }
    }

    private function storeUpload($file) {
        if (!is_array($file) || !isset($file['error'], $file['tmp_name'], $file['size']) || !is_scalar($file['error']) || !is_string($file['tmp_name']) || !is_scalar($file['size']) || (int)$file['error'] !== UPLOAD_ERR_OK || (int)$file['size'] < 1 || (int)$file['size'] > 5 * 1024 * 1024 || !is_uploaded_file($file['tmp_name'])) {
            throw new \InvalidArgumentException($this->language->get('error_image'));
        }
        $size = @getimagesize($file['tmp_name']);
        if (!$size || $size[0] < 10 || $size[1] < 10 || $size[0] > 6000 || $size[1] > 6000 || $size[0] * $size[1] > 12000000) { throw new \InvalidArgumentException($this->language->get('error_image')); }
        if (!function_exists('imagecreatefromjpeg') || !function_exists('imagepng')) { throw new \RuntimeException($this->language->get('error_gd')); }
        $type = isset($size['mime']) ? $size['mime'] : '';
        if ($type === 'image/jpeg') { $image = @imagecreatefromjpeg($file['tmp_name']); }
        elseif ($type === 'image/png') { $image = @imagecreatefrompng($file['tmp_name']); }
        elseif ($type === 'image/webp' && function_exists('imagecreatefromwebp')) { $image = @imagecreatefromwebp($file['tmp_name']); }
        else { throw new \InvalidArgumentException($this->language->get('error_image')); }
        if (!$image) { throw new \InvalidArgumentException($this->language->get('error_image')); }
        $relative = 'catalog/c2c/' . (int)$this->seller['seller_id'] . '/';
        $directory = DIR_IMAGE . $relative;
        if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) { imagedestroy($image); throw new \RuntimeException($this->language->get('error_upload_dir')); }
        $root = realpath(DIR_IMAGE); $actual = realpath($directory);
        if (!$root || !$actual || strpos($actual . DIRECTORY_SEPARATOR, $root . DIRECTORY_SEPARATOR) !== 0) { imagedestroy($image); throw new \RuntimeException($this->language->get('error_upload_dir')); }
        $name = bin2hex(random_bytes(20)) . '.png';
        imagealphablending($image, false); imagesavealpha($image, true);
        $ok = imagepng($image, $directory . $name, 6); imagedestroy($image);
        if (!$ok) { throw new \RuntimeException($this->language->get('error_upload_dir')); }
        return $relative . $name;
    }

    private function rotateSession() {
        $saved = array();
        foreach (array('language', 'currency', 'customer_id') as $key) { if (isset($this->session->data[$key])) { $saved[$key] = $this->session->data[$key]; } }
        $this->session->destroy(); $this->session->start(); $this->session->data = $saved;
        setcookie($this->config->get('session_name'), $this->session->getId(), array('expires' => 0, 'path' => '/', 'secure' => $this->isHttps(), 'httponly' => true, 'samesite' => 'Lax'));
    }
    private function forgetRemember() {
        if (is_file(DIR_APPLICATION . 'model/extension/module/codervia_remember.php')) {
            $this->load->model('extension/module/codervia_remember'); $this->model_extension_module_codervia_remember->forget();
        }
    }
    private function token() { if (empty($this->session->data['c2c_csrf'])) { $this->session->data['c2c_csrf'] = bin2hex(random_bytes(32)); } return $this->session->data['c2c_csrf']; }
    private function fields($names) { $data = array(); foreach ($names as $name) { $data[$name] = $this->text($name); } return $data; }
    private function text($name) { return isset($this->request->post[$name]) && is_scalar($this->request->post[$name]) ? (string)$this->request->post[$name] : ''; }
    private function flash($key, $value) { $this->session->data['c2c_' . $key] = $value; }
    private function money($value) { return html_entity_decode($this->currency->format((float)$value, $this->config->get('config_currency'), 1), ENT_QUOTES, 'UTF-8'); }
    private function orderMoney($value, $order) { return html_entity_decode($this->currency->format((float)$value, $order['currency_code'], isset($order['currency_value']) ? (float)$order['currency_value'] : 1), ENT_QUOTES, 'UTF-8'); }
    private function brand() { $brand = trim((string)$this->config->get('module_c2c_marketplace_brand')); return $brand ? $brand : 'Pazar Yeri'; }
    private function isHttps() { return !empty($this->request->server['HTTPS']) && strtolower($this->request->server['HTTPS']) !== 'off'; }
    private function base() {
        $canonical = $this->isHttps() && $this->config->get('config_ssl') ? $this->config->get('config_ssl') : $this->config->get('config_url');
        if (!$canonical) { $canonical = defined('HTTPS_SERVER') && $this->isHttps() ? HTTPS_SERVER : HTTP_SERVER; }
        $partner = strtolower(trim((string)$this->config->get('module_c2c_marketplace_partner_host')));
        $request_host = isset($this->request->server['HTTP_HOST']) ? strtolower($this->request->server['HTTP_HOST']) : '';
        if ($partner && preg_match('/^(?=.{1,253}$)[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/D', $partner) && $request_host === $partner) {
            $path = parse_url($canonical, PHP_URL_PATH); return ($this->isHttps() ? 'https://' : 'http://') . $partner . '/' . trim((string)$path, '/') . ($path && trim($path, '/') ? '/' : '');
        }
        return rtrim($canonical, '/') . '/';
    }
    private function panelUrl($method = '', $args = array()) {
        return $this->base() . 'index.php?' . http_build_query(array('route' => 'extension/module/c2c_partner' . ($method ? '/' . $method : '')) + $args, '', '&');
    }
    private function publicUrl($route, $args = '') { return html_entity_decode($this->url->link($route, $args, $this->isHttps()), ENT_QUOTES, 'UTF-8'); }
    private function notFound() { $this->response->addHeader('HTTP/1.1 404 Not Found'); $this->response->setOutput('Sayfa bulunamadı / Page not found'); }
}
