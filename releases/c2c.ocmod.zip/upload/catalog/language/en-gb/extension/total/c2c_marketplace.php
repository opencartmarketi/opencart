<?php
$_['text_campaign'] = 'Store promotion';
