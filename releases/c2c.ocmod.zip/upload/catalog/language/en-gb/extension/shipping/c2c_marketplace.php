<?php
$_['text_title'] = 'Shipping by store';
$_['text_description'] = 'Store shipping fees and eligible promotions';
