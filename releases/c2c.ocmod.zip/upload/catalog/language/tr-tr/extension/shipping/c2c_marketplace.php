<?php
$_['text_title'] = 'Mağaza bazlı kargo';
$_['text_description'] = 'Mağazaların kargo ücretleri ve geçerli kampanyalar';
