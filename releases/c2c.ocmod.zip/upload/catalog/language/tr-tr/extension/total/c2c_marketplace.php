<?php
$_['text_campaign'] = 'Mağaza kampanyası';
