<?php
class ModelExtensionShippingC2cMarketplace extends Model {
    public function getQuote($address) {
        if (!$this->config->get('module_c2c_marketplace_status') || !$this->config->get('shipping_c2c_marketplace_status') || (int)$this->config->get('config_store_id') !== 0) return array();
        $this->load->library('c2c/campaigns');
        $quote = $this->campaigns->shippingQuote($this->cart->getProducts(), (int)$this->customer->getId());
        if (!$quote['breakdown']) return array();
        $this->load->language('extension/shipping/c2c_marketplace');
        $cost = $quote['cost'];
        $currency = isset($this->session->data['currency']) ? $this->session->data['currency'] : $this->config->get('config_currency');
        return array('code'=>'c2c_marketplace','title'=>$this->language->get('text_title'),'quote'=>array('standard'=>array('code'=>'c2c_marketplace.standard','title'=>$this->language->get('text_description'),'cost'=>$cost,'tax_class_id'=>0,'text'=>$this->currency->format($cost,$currency))),'sort_order'=>$this->config->get('shipping_c2c_marketplace_sort_order') === null ? 1 : (int)$this->config->get('shipping_c2c_marketplace_sort_order'),'error'=>false);
    }
}
