<?php
class ModelExtensionTotalC2cMarketplace extends Model {
    public function getTotal($total) {
        unset($this->session->data['c2c_campaign_allocation']);
        if (!$this->config->get('module_c2c_marketplace_status') || !$this->config->get('total_c2c_marketplace_status') || (int)$this->config->get('config_store_id') !== 0) return;
        // Seller promotions never stack with a native coupon or reward-points discount.
        if (!empty($this->session->data['coupon']) || !empty($this->session->data['reward'])) return;
        foreach ($total['totals'] as $row) if (isset($row['value']) && (float)$row['value'] < 0) return;
        $this->load->library('c2c/campaigns');
        $products = $this->cart->getProducts();
        $allocation = $this->campaigns->calculate($products, (int)$this->customer->getId());
        if ($allocation['discount'] <= 0) return;
        // A nonstandard total extension running earlier must not cause a negative payable total.
        if ($allocation['discount'] > max(0, (float)$total['total']) + 0.00005) return;
        foreach ($allocation['lines'] as $line) {
            if (!$line['tax_class_id']) continue;
            foreach ($this->tax->getRates($line['discount'], $line['tax_class_id']) as $rate) {
                if ($rate['type'] === 'P' && isset($total['taxes'][$rate['tax_rate_id']])) {
                    $total['taxes'][$rate['tax_rate_id']] = max(0, $total['taxes'][$rate['tax_rate_id']] - $rate['amount']);
                }
            }
        }
        $this->load->language('extension/total/c2c_marketplace');
        $total['totals'][] = array('code'=>'c2c_marketplace','title'=>$this->language->get('text_campaign'),'value'=>-$allocation['discount'],'sort_order'=>$this->config->get('total_c2c_marketplace_sort_order') === null ? 4 : (int)$this->config->get('total_c2c_marketplace_sort_order'));
        $total['total'] -= $allocation['discount'];
        $cart = array();
        foreach ($products as $product) $cart[] = array('product_id'=>(int)$product['product_id'],'quantity'=>(int)$product['quantity'],'price'=>(float)$product['price'],'total'=>(float)$product['total'],'tax_class_id'=>(int)$product['tax_class_id']);
        $this->session->data['c2c_campaign_allocation'] = $allocation + array('customer_id'=>(int)$this->customer->getId(),'cart'=>$cart,'fingerprint'=>hash('sha256',json_encode($cart)));
    }
}
