<?php
namespace C2c;

/** Seller-scoped cart promotions. Money follows OpenCart's base-currency amounts. */
class Campaigns {
    private $db;
    private $config;

    public function __construct($registry) {
        $this->db = $registry->get('db');
        $this->config = $registry->get('config');
    }

    public function install() {
        $this->db->query('CREATE TABLE IF NOT EXISTS `' . DB_PREFIX . "c2c_campaign` (campaign_id INT UNSIGNED NOT NULL AUTO_INCREMENT,seller_id INT UNSIGNED NOT NULL,name VARCHAR(100) NOT NULL,type VARCHAR(32) NOT NULL,value DECIMAL(15,4) NOT NULL DEFAULT 0,threshold DECIMAL(15,4) NOT NULL DEFAULT 0,status TINYINT NOT NULL DEFAULT 0,date_start DATE NOT NULL,date_end DATE NOT NULL,date_added DATETIME NOT NULL,date_modified DATETIME NOT NULL,PRIMARY KEY(campaign_id),KEY seller_type(seller_id,type,status),KEY active_dates(status,date_start,date_end)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }

    public function getCampaigns($seller_id, $activeOnly = false) {
        $seller_id = (int)$seller_id;
        if ($seller_id < 1) return array();
        $where = ' WHERE c.seller_id=' . $seller_id;
        if ($activeOnly) {
            $where .= " AND s.status='approved' AND c.status=1 AND c.date_start<=" . $this->quote(date('Y-m-d')) . ' AND c.date_end>=' . $this->quote(date('Y-m-d'));
        }
        return $this->db->query('SELECT c.* FROM `' . DB_PREFIX . 'c2c_campaign` c JOIN `' . DB_PREFIX . 'c2c_seller` s ON s.seller_id=c.seller_id' . $where . ' ORDER BY c.campaign_id DESC')->rows;
    }

    public function saveCampaign($seller_id, $data, $campaign_id = 0) {
        $seller_id = (int)$seller_id;
        $campaign_id = (int)$campaign_id;
        $name = $this->text(isset($data['name']) ? $data['name'] : '', 2, 100, 'Kampanya adı');
        $type = isset($data['type']) && is_scalar($data['type']) ? (string)$data['type'] : '';
        if (!in_array($type, array('buy3pay2','follower_percent','shipping_free','shipping_threshold'), true)) throw new \InvalidArgumentException('Geçersiz kampanya türü.');
        $value = $type === 'follower_percent' ? $this->amount(isset($data['value']) ? $data['value'] : '', false) : '0.0000';
        if ($type === 'follower_percent' && ((float)$value < 0.01 || (float)$value > 50)) throw new \InvalidArgumentException('Takipçi indirimi %0,01–%50 arasında olmalı.');
        $threshold = $type === 'shipping_threshold' ? $this->amount(isset($data['threshold']) ? $data['threshold'] : '', false) : '0.0000';
        if ($type === 'shipping_threshold' && (float)$threshold <= 0) throw new \InvalidArgumentException('Ücretsiz kargo alt limiti sıfırdan büyük olmalı.');
        $status = isset($data['status']) && is_scalar($data['status']) ? (string)$data['status'] : '';
        if (!in_array($status, array('0','1'), true)) throw new \InvalidArgumentException('Kampanya durumu geçersiz.');
        $date_start = $this->date(isset($data['date_start']) ? $data['date_start'] : '');
        $date_end = $this->date(isset($data['date_end']) ? $data['date_end'] : '');
        if ($date_end < $date_start) throw new \InvalidArgumentException('Bitiş tarihi başlangıçtan önce olamaz.');
        $lock = 'c2c_campaign_' . substr(hash('sha256', DB_PREFIX . ':' . $seller_id), 0, 40);
        $got = $this->db->query('SELECT GET_LOCK(' . $this->quote($lock) . ',5) AS locked')->row;
        if (empty($got['locked'])) throw new \RuntimeException('Kampanya şu anda güncelleniyor. Lütfen yeniden deneyin.');
        $transaction = false;
        try {
            $this->approvedSeller($seller_id);
            $this->db->query('START TRANSACTION');
            $transaction = true;
            if ($campaign_id > 0) {
                $existing = $this->db->query('SELECT campaign_id FROM `' . DB_PREFIX . 'c2c_campaign` WHERE campaign_id=' . $campaign_id . ' AND seller_id=' . $seller_id . ' FOR UPDATE')->row;
                if (!$existing) throw new \InvalidArgumentException('Kampanya bulunamadı veya bu mağazaya ait değil.');
            }
            if ($status === '1') {
                $this->db->query('UPDATE `' . DB_PREFIX . 'c2c_campaign` SET status=0,date_modified=NOW() WHERE seller_id=' . $seller_id . ' AND type=' . $this->quote($type) . ' AND campaign_id<>' . $campaign_id);
            }
            $set = 'seller_id=' . $seller_id . ',name=' . $this->quote($name) . ',type=' . $this->quote($type) . ',value=' . $value . ',threshold=' . $threshold . ',status=' . (int)$status . ',date_start=' . $this->quote($date_start) . ',date_end=' . $this->quote($date_end) . ',date_modified=NOW()';
            if ($campaign_id > 0) $this->db->query('UPDATE `' . DB_PREFIX . 'c2c_campaign` SET ' . $set . ' WHERE campaign_id=' . $campaign_id . ' AND seller_id=' . $seller_id);
            else {
                $this->db->query('INSERT INTO `' . DB_PREFIX . 'c2c_campaign` SET ' . $set . ',date_added=NOW()');
                $campaign_id = (int)$this->db->getLastId();
            }
            $this->db->query('COMMIT');
            $transaction = false;
            return $campaign_id;
        } finally {
            if ($transaction) $this->db->query('ROLLBACK');
            $this->db->query('SELECT RELEASE_LOCK(' . $this->quote($lock) . ')');
        }
    }

    /** Calculates product discounts independently for every approved seller. */
    public function calculate($products, $customer_id = 0) {
        $result = array('discount'=>0.0,'lines'=>array(),'sellers'=>array(),'shipping'=>array(),'description'=>'Mağaza kampanyası');
        if (!$this->enabled() || !is_array($products) || !$products) return $result;
        $groups = $this->groups($products);
        foreach ($groups as $seller_id => $group) {
            if (!$seller_id) continue;
            $campaigns = $this->getCampaigns($seller_id, true);
            $byType = array();
            foreach ($campaigns as $campaign) if (!isset($byType[$campaign['type']])) $byType[$campaign['type']] = $campaign;
            $subtotal = $group['subtotal'];
            $result['shipping'][$seller_id] = array('free'=>isset($byType['shipping_free']) || (isset($byType['shipping_threshold']) && $subtotal + 0.00005 >= (float)$byType['shipping_threshold']['threshold']), 'subtotal'=>$subtotal);
            $buyLines = array(); $buyAmount = 0.0;
            if (isset($byType['buy3pay2'])) {
                $units = 0;
                foreach ($group['lines'] as $line) $units += $line['quantity'];
                $freeUnits = intdiv($units, 3);
                $sorted = $group['lines'];
                usort($sorted, function($a,$b) { if ($a['unit'] == $b['unit']) return $a['index'] <=> $b['index']; return $a['unit'] <=> $b['unit']; });
                foreach ($sorted as $line) {
                    if (!$freeUnits) break;
                    $free = min($freeUnits, $line['quantity']);
                    $discount = round($free * $line['unit'], 4);
                    if ($discount > 0) { $buyLines[$line['index']] = $discount; $buyAmount += $discount; }
                    $freeUnits -= $free;
                }
            }
            $followLines = array(); $followAmount = 0.0;
            if (isset($byType['follower_percent']) && $this->following($seller_id, (int)$customer_id)) {
                $rate = min(50, max(0, (float)$byType['follower_percent']['value']));
                foreach ($group['lines'] as $line) {
                    $discount = round($line['total'] * $rate / 100, 4);
                    if ($discount > 0) { $followLines[$line['index']] = $discount; $followAmount += $discount; }
                }
            }
            $useFollow = $followAmount > $buyAmount;
            $chosen = $useFollow ? $followLines : $buyLines;
            $amount = round($useFollow ? $followAmount : $buyAmount, 4);
            if ($amount <= 0) continue;
            $label = $useFollow ? 'Takipçiye özel indirim' : '3 al 2 öde';
            $result['sellers'][$seller_id] = array('discount'=>$amount, 'label'=>$label);
            $result['discount'] += $amount;
            foreach ($group['lines'] as $line) {
                if (!isset($chosen[$line['index']])) continue;
                $result['lines'][] = array('product_id'=>$line['product_id'],'tax_class_id'=>$line['tax_class_id'],'discount'=>$chosen[$line['index']],'seller_id'=>$seller_id,'cart_id'=>$line['cart_id'],'index'=>$line['index']);
            }
        }
        $result['discount'] = round($result['discount'], 4);
        return $result;
    }

    /** Fixed per-merchant shipping method. Other carriers are never changed. */
    public function shippingQuote($products, $customer_id = 0) {
        $result = array('cost'=>0.0,'breakdown'=>array());
        if (!$this->enabled() || !$this->config->get('shipping_c2c_marketplace_status') || !is_array($products)) return $result;
        $baseline = $this->config->get('shipping_c2c_marketplace_cost');
        $baseline = $baseline === null || $baseline === '' ? 30.0 : (float)$this->amount($baseline, true);
        $campaigns = $this->calculate($products, $customer_id);
        foreach ($this->groups($products) as $seller_id=>$group) {
            $shippable = false;
            foreach ($group['lines'] as $line) if ($line['shipping']) { $shippable=true; break; }
            if (!$shippable) continue;
            $free = $seller_id > 0 && !empty($campaigns['shipping'][$seller_id]['free']);
            $cost = $free ? 0.0 : $baseline;
            $result['breakdown'][] = array('seller_id'=>$seller_id,'store_name'=>$group['store_name'],'free'=>$free,'cost'=>$cost);
            $result['cost'] += $cost;
        }
        $result['cost'] = round($result['cost'],4);
        return $result;
    }

    private function groups($products) {
        $ids = array();
        foreach ($products as $product) if (is_array($product) && !empty($product['product_id'])) $ids[(int)$product['product_id']] = (int)$product['product_id'];
        $owners = array();
        if ($ids) {
            $rows = $this->db->query('SELECT cp.product_id,cp.seller_id,s.store_name FROM `' . DB_PREFIX . 'c2c_product` cp JOIN `' . DB_PREFIX . "c2c_seller` s ON s.seller_id=cp.seller_id AND s.status='approved' JOIN `" . DB_PREFIX . "product` p ON p.product_id=cp.product_id AND p.status=1 AND p.date_available<=CURDATE() JOIN `" . DB_PREFIX . "product_to_store` ps ON ps.product_id=p.product_id AND ps.store_id=0 WHERE cp.approval='approved' AND cp.product_id IN (" . implode(',',$ids) . ')')->rows;
            foreach ($rows as $row) $owners[(int)$row['product_id']] = $row;
        }
        $groups = array(); $index = 0;
        foreach ($products as $product) {
            $originalIndex = $index++;
            if (!is_array($product)) continue;
            $product_id = isset($product['product_id']) ? (int)$product['product_id'] : 0;
            $quantity = isset($product['quantity']) ? (int)$product['quantity'] : 0;
            $total = isset($product['total']) ? (float)$product['total'] : 0;
            if ($product_id<1 || $quantity<1 || $quantity>1000000 || !is_finite($total) || $total<0 || $total>99999999999.9999) continue;
            $owner = isset($owners[$product_id]) ? $owners[$product_id] : array('seller_id'=>0,'store_name'=>'Mağaza');
            $seller_id = (int)$owner['seller_id'];
            if (!isset($groups[$seller_id])) $groups[$seller_id] = array('store_name'=>$owner['store_name'],'subtotal'=>0.0,'lines'=>array());
            $groups[$seller_id]['subtotal'] += $total;
            $groups[$seller_id]['lines'][] = array('index'=>$originalIndex,'product_id'=>$product_id,'quantity'=>$quantity,'unit'=>$total/$quantity,'total'=>$total,'tax_class_id'=>isset($product['tax_class_id'])?(int)$product['tax_class_id']:0,'shipping'=>!empty($product['shipping']),'cart_id'=>isset($product['cart_id'])?(string)$product['cart_id']:'');
        }
        return $groups;
    }

    private function following($seller_id, $customer_id) {
        if ($customer_id < 1) return false;
        return (bool)$this->db->query('SELECT f.customer_id FROM `' . DB_PREFIX . 'c2c_follow` f JOIN `' . DB_PREFIX . 'customer` c ON c.customer_id=f.customer_id AND c.status=1 WHERE f.seller_id=' . (int)$seller_id . ' AND f.customer_id=' . (int)$customer_id . ' LIMIT 1')->num_rows;
    }

    private function approvedSeller($seller_id) {
        if ($seller_id<1 || !$this->db->query('SELECT s.seller_id FROM `' . DB_PREFIX . 'c2c_seller` s JOIN `' . DB_PREFIX . "customer` c ON c.customer_id=s.customer_id AND c.status=1 WHERE s.seller_id=" . (int)$seller_id . " AND s.status='approved' LIMIT 1")->num_rows) throw new \InvalidArgumentException('Kampanya için onaylı mağaza gerekli.');
    }
    private function enabled() { return (bool)$this->config->get('module_c2c_marketplace_status') && (int)$this->config->get('config_store_id')===0; }
    private function quote($value) { return "'" . $this->db->escape((string)$value) . "'"; }
    private function text($value,$min,$max,$label) {
        if (!is_scalar($value)) throw new \InvalidArgumentException($label . ' geçersiz.');
        $value=trim(strip_tags(html_entity_decode((string)$value,ENT_QUOTES,'UTF-8')));
        if (preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/',$value) || utf8_strlen($value)<$min || utf8_strlen($value)>$max) throw new \InvalidArgumentException($label . ' ' . $min . '–' . $max . ' karakter olmalı.');
        return $value;
    }
    private function amount($value,$allowZero) {
        if (!is_scalar($value) || !preg_match('/^(0|[1-9][0-9]{0,7})(\.[0-9]{1,4})?$/D',(string)$value) || (!$allowZero && (float)$value<=0)) throw new \InvalidArgumentException('Tutar ondalık nokta ile geçerli pozitif sayı olmalı.');
        return number_format((float)$value,4,'.','');
    }
    private function date($value) {
        if (!is_string($value) || !preg_match('/^20[0-9]{2}-[0-9]{2}-[0-9]{2}$/D',$value)) throw new \InvalidArgumentException('Geçerli başlangıç ve bitiş tarihi gerekli.');
        $parsed=\DateTimeImmutable::createFromFormat('!Y-m-d',$value);
        if (!$parsed || $parsed->format('Y-m-d')!==$value) throw new \InvalidArgumentException('Kampanya tarihi geçersiz.');
        return $value;
    }
}
