<?php
namespace C2c;

/**
 * C2C Marketplace business rules for OpenCart 3.0.5.1.
 * All monetary database values follow OpenCart: amounts are in store base currency;
 * currency_value is retained exclusively for order-currency presentation.
 */
class Marketplace {
    private $db;
    private $config;
    private $cache;
    private $registry;

    public function __construct($registry) {
        $this->registry = $registry;
        $this->db = $registry->get('db');
        $this->config = $registry->get('config');
        $this->cache = $registry->get('cache');
    }

    public function isEnabled() {
        return (bool)$this->config->get('module_c2c_marketplace_status') && (int)$this->config->get('config_store_id') === 0;
    }

    public function install() {
        $schemas = array(
            'c2c_seller' => "seller_id INT UNSIGNED NOT NULL AUTO_INCREMENT, customer_id INT NOT NULL, store_name VARCHAR(100) NOT NULL, slug VARCHAR(64) NOT NULL, description TEXT NOT NULL, phone VARCHAR(32) NOT NULL DEFAULT '', legal_name VARCHAR(160) NOT NULL DEFAULT '', status VARCHAR(16) NOT NULL DEFAULT 'pending', date_added DATETIME NOT NULL, date_modified DATETIME NOT NULL, PRIMARY KEY(seller_id), UNIQUE KEY customer_id(customer_id), UNIQUE KEY slug(slug), KEY status(status)",
            'c2c_product' => "product_id INT NOT NULL, seller_id INT UNSIGNED NOT NULL, approval VARCHAR(16) NOT NULL DEFAULT 'pending', lead_time TINYINT UNSIGNED NOT NULL DEFAULT 2, date_added DATETIME NOT NULL, date_modified DATETIME NOT NULL, PRIMARY KEY(product_id), KEY seller_approval(seller_id,approval)",
            'c2c_order_item' => "id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, order_product_id INT NOT NULL, order_id INT NOT NULL, seller_id INT UNSIGNED NOT NULL, product_id INT NOT NULL, name VARCHAR(255) NOT NULL, quantity INT NOT NULL, total DECIMAL(15,4) NOT NULL, discount DECIMAL(15,4) NOT NULL DEFAULT 0, eligible_total DECIMAL(15,4) NOT NULL, commission_rate DECIMAL(7,4) NOT NULL, commission DECIMAL(15,4) NOT NULL, net DECIMAL(15,4) NOT NULL, currency_code VARCHAR(3) NOT NULL, currency_value DECIMAL(15,8) NOT NULL, base_currency_code VARCHAR(3) NOT NULL, date_added DATETIME NOT NULL, PRIMARY KEY(id), UNIQUE KEY order_product(order_product_id), KEY seller_order(seller_id,order_id), KEY order_id(order_id)",
            'c2c_order_state' => "order_id INT NOT NULL, snapshot_hash CHAR(64) NOT NULL, needs_review TINYINT NOT NULL DEFAULT 0, date_modified DATETIME NOT NULL, PRIMARY KEY(order_id)",
            'c2c_shipment' => "seller_id INT UNSIGNED NOT NULL, order_id INT NOT NULL, shipping_company VARCHAR(100) NOT NULL, tracking_number VARCHAR(100) NOT NULL, date_modified DATETIME NOT NULL, PRIMARY KEY(seller_id,order_id)",
            'c2c_settlement' => "settlement_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, seller_id INT UNSIGNED NOT NULL, amount DECIMAL(15,2) NOT NULL, currency_code VARCHAR(3) NOT NULL, reference VARCHAR(128) NOT NULL, admin_user_id INT NOT NULL, date_added DATETIME NOT NULL, PRIMARY KEY(settlement_id), UNIQUE KEY seller_reference(seller_id,reference), KEY seller_date(seller_id,date_added)",
            'c2c_question' => "question_id INT UNSIGNED NOT NULL AUTO_INCREMENT, product_id INT NOT NULL, seller_id INT UNSIGNED NOT NULL, customer_id INT NOT NULL, question TEXT NOT NULL, answer TEXT NOT NULL, date_added DATETIME NOT NULL, date_answered DATETIME DEFAULT NULL, PRIMARY KEY(question_id), KEY seller_question(seller_id,question_id), KEY product_answer(product_id,date_answered), KEY customer_date(customer_id,date_added)"
        );
        foreach ($schemas as $table => $schema) {
            $this->db->query('CREATE TABLE IF NOT EXISTS `' . DB_PREFIX . $table . '` (' . $schema . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
        }
        // Additive migrations affect only this extension's own tables.
        $this->ensureColumn('c2c_product', 'lead_time', 'TINYINT UNSIGNED NOT NULL DEFAULT 2');
        $this->ensureColumn('c2c_order_item', 'discount', 'DECIMAL(15,4) NOT NULL DEFAULT 0');
        if ($this->ensureColumn('c2c_order_item', 'eligible_total', 'DECIMAL(15,4) NOT NULL DEFAULT 0')) {
            $this->db->query('UPDATE `' . DB_PREFIX . 'c2c_order_item` SET eligible_total=total');
        }
        require_once __DIR__ . '/social.php';
        require_once __DIR__ . '/campaigns.php';
        (new Social($this->registry))->install();
        (new Campaigns($this->registry))->install();
    }

    public function uninstall() {
        // Order evidence, seller ownership and payment records must survive uninstall.
        $this->pauseInventory();
    }

    public function pauseInventory() {
        // Disabled event handlers must not leave seller inventory purchasable
        // without its ownership/commission accounting. Preserve every record.
        $lock = $this->lock('inventory');
        try {
            $this->db->query("UPDATE `" . DB_PREFIX . "product` p JOIN `" . DB_PREFIX . "c2c_product` cp ON cp.product_id=p.product_id SET p.status=0,p.date_modified=NOW()");
            $this->db->query("UPDATE `" . DB_PREFIX . "c2c_product` SET approval='pending',date_modified=NOW() WHERE approval='approved'");
            $this->clearProductCache();
        } finally {
            $this->unlock($lock);
        }
    }

    public function getSellerByCustomer($customer_id) {
        if ((int)$customer_id < 1) return array();
        return $this->db->query("SELECT * FROM `" . DB_PREFIX . "c2c_seller` WHERE customer_id=" . (int)$customer_id . " LIMIT 1")->row;
    }

    public function getSeller($seller_id, $public = false) {
        if ((int)$seller_id < 1) return array();
        if ($public) {
            return $this->db->query("SELECT seller_id,store_name,slug,description,date_added FROM `" . DB_PREFIX . "c2c_seller` WHERE seller_id=" . (int)$seller_id . " AND status='approved' LIMIT 1")->row;
        }
        return $this->db->query("SELECT * FROM `" . DB_PREFIX . "c2c_seller` WHERE seller_id=" . (int)$seller_id . " LIMIT 1")->row;
    }

    public function apply($customer_id, $data) {
        $customer_id = (int)$customer_id;
        $this->requireCustomer($customer_id);
        $fields = $this->sellerFields($data);
        $slug = isset($data['slug']) && is_scalar($data['slug']) ? strtolower(trim((string)$data['slug'])) : '';
        if (!preg_match('/^[a-z0-9][a-z0-9-]{1,62}[a-z0-9]$/D', $slug)) {
            throw new \InvalidArgumentException('Mağaza adresi 3–64 karakter olmalı; küçük harf, rakam ve arada tire kullanın.');
        }
        $lock = $this->lock('apply');
        try {
            if ($this->getSellerByCustomer($customer_id)) throw new \InvalidArgumentException('Bu hesaba ait mağaza başvurusu zaten var.');
            if ($this->db->query("SELECT seller_id FROM `" . DB_PREFIX . "c2c_seller` WHERE slug=" . $this->q($slug) . " LIMIT 1")->num_rows) {
                throw new \InvalidArgumentException('Bu mağaza adresi kullanılıyor.');
            }
            $this->db->query("INSERT INTO `" . DB_PREFIX . "c2c_seller` SET customer_id=" . $customer_id . ", store_name=" . $this->q($fields['store_name']) . ", slug=" . $this->q($slug) . ", description=" . $this->q($fields['description']) . ", phone=" . $this->q($fields['phone']) . ", legal_name=" . $this->q($fields['legal_name']) . ", status='pending',date_added=NOW(),date_modified=NOW()");
            return (int)$this->db->getLastId();
        } finally {
            $this->unlock($lock);
        }
    }

    public function updateSeller($seller_id, $data) {
        $seller_id = $this->requireSeller($seller_id, false)['seller_id'];
        $fields = $this->sellerFields($data);
        $this->db->query("UPDATE `" . DB_PREFIX . "c2c_seller` SET store_name=" . $this->q($fields['store_name']) . ",description=" . $this->q($fields['description']) . ",phone=" . $this->q($fields['phone']) . ",legal_name=" . $this->q($fields['legal_name']) . ",date_modified=NOW() WHERE seller_id=" . (int)$seller_id);
    }

    public function getSellers($status = '', $start = 0, $limit = 50) {
        $where = '';
        if ($status !== '') {
            $this->enum($status, array('pending','approved','suspended'));
            $where = ' WHERE status=' . $this->q($status);
        }
        return $this->db->query("SELECT * FROM `" . DB_PREFIX . "c2c_seller`" . $where . " ORDER BY seller_id DESC" . $this->limit($start, $limit))->rows;
    }

    public function setSellerStatus($seller_id, $status) {
        $this->enum($status, array('pending','approved','suspended'));
        $lock = $this->lock('seller_' . (int)$seller_id);
        try {
            $seller = $this->requireSeller($seller_id, false);
            if ($status === 'approved') $this->requireCustomer($seller['customer_id']);
            $this->db->query("UPDATE `" . DB_PREFIX . "c2c_seller` SET status=" . $this->q($status) . ",date_modified=NOW() WHERE seller_id=" . (int)$seller_id);
            if ($status !== 'approved') {
                $this->db->query("UPDATE `" . DB_PREFIX . "product` p JOIN `" . DB_PREFIX . "c2c_product` cp ON cp.product_id=p.product_id SET p.status=0,p.date_modified=NOW() WHERE cp.seller_id=" . (int)$seller_id);
                $this->db->query("UPDATE `" . DB_PREFIX . "c2c_product` SET approval='pending',date_modified=NOW() WHERE seller_id=" . (int)$seller_id . " AND approval='approved'");
            }
            $this->clearProductCache();
        } finally {
            $this->unlock($lock);
        }
    }

    public function getCategories() {
        return $this->db->query("SELECT c.category_id,cd.name FROM `" . DB_PREFIX . "category` c JOIN `" . DB_PREFIX . "category_description` cd ON cd.category_id=c.category_id JOIN `" . DB_PREFIX . "category_to_store` cs ON cs.category_id=c.category_id AND cs.store_id=0 WHERE c.status=1 AND cd.language_id=" . $this->languageId() . " ORDER BY cd.name,c.category_id")->rows;
    }

    public function getProducts($seller_id, $start = 0, $limit = 20) {
        $this->requireSeller($seller_id, false);
        return $this->decodeProducts($this->db->query($this->productSelect() . " WHERE cp.seller_id=" . (int)$seller_id . " ORDER BY p.product_id DESC" . $this->limit($start, $limit))->rows);
    }

    public function countProducts($seller_id) {
        $this->requireSeller($seller_id, false);
        return (int)$this->db->query("SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "c2c_product` cp JOIN `" . DB_PREFIX . "product` p ON p.product_id=cp.product_id WHERE cp.seller_id=" . (int)$seller_id)->row['total'];
    }

    public function getProduct($seller_id, $product_id) {
        $row = $this->db->query($this->productSelect() . " WHERE cp.seller_id=" . (int)$seller_id . " AND p.product_id=" . (int)$product_id . " LIMIT 1")->row;
        if (!$row) return array();
        $row = $this->decodeProducts(array($row))[0];
        $row['description'] = html_entity_decode(strip_tags(html_entity_decode($row['description'], ENT_QUOTES, 'UTF-8')), ENT_QUOTES, 'UTF-8');
        $category = $this->db->query("SELECT category_id FROM `" . DB_PREFIX . "product_to_category` WHERE product_id=" . (int)$product_id . " ORDER BY category_id LIMIT 1")->row;
        $row['category_id'] = $category ? (int)$category['category_id'] : 0;
        return $row;
    }

    public function saveProduct($seller_id, $data, $product_id = 0) {
        $this->requireSeller($seller_id, true);
        $seller_id = (int)$seller_id;
        $product_id = (int)$product_id;
        $name = $this->text(isset($data['name']) ? $data['name'] : '', 255, 1, 'Ürün adı');
        $model = $this->text(isset($data['model']) ? $data['model'] : '', 64, 1, 'Ürün kodu');
        // Native OpenCart product/cart templates expect Request::clean-encoded
        // product strings, including attribute quotes. Our text validator decodes
        // input, so restore that storage convention before writing core tables.
        $name = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
        $model = htmlspecialchars($model, ENT_QUOTES, 'UTF-8');
        if ($this->length($name) > 255 || $this->length($model) > 64) throw new \InvalidArgumentException('Ürün adı veya kodu HTML kodlaması sonrasında çok uzun. Lütfen kısaltın.');
        $description = $this->text(isset($data['description']) ? $data['description'] : '', 10000, 0, 'Ürün açıklaması');
        $price = $this->decimal(isset($data['price']) ? $data['price'] : '', 8, 4, false);
        $quantity = isset($data['quantity']) && is_scalar($data['quantity']) ? (string)$data['quantity'] : '';
        if (!preg_match('/^(0|[1-9][0-9]{0,5})$/D', $quantity)) throw new \InvalidArgumentException('Stok 0–999999 arasında tam sayı olmalı.');
        if (array_key_exists('lead_time', $data) && !is_scalar($data['lead_time'])) throw new \InvalidArgumentException('Kargoya hazırlık süresi geçersiz.');
        $lead_time = array_key_exists('lead_time', $data) ? (string)$data['lead_time'] : '2';
        if (!preg_match('/^(?:0|[1-9][0-9]?)$/D', $lead_time) || (int)$lead_time > 60) throw new \InvalidArgumentException('Kargoya hazırlık süresi 0–60 gün arasında tam sayı olmalı.');
        $category_id = isset($data['category_id']) ? (int)$data['category_id'] : 0;
        $category = $this->db->query("SELECT c.category_id FROM `" . DB_PREFIX . "category` c JOIN `" . DB_PREFIX . "category_to_store` cs ON cs.category_id=c.category_id AND cs.store_id=0 WHERE c.category_id=" . $category_id . " AND c.status=1 LIMIT 1")->row;
        if (!$category) throw new \InvalidArgumentException('Geçerli bir kategori seçin.');
        $image = isset($data['image']) && is_scalar($data['image']) ? (string)$data['image'] : '';
        if ($image !== '') {
            $pattern = '#^catalog/c2c/' . $seller_id . '/[a-f0-9]{32,64}\.(jpg|jpeg|png|webp)$#D';
            if (!preg_match($pattern, $image) || !defined('DIR_IMAGE') || !is_file(DIR_IMAGE . $image)) throw new \InvalidArgumentException('Yalnızca bu mağazanın panelden yüklenmiş görselleri kullanılabilir.');
            $real = realpath(DIR_IMAGE . $image);
            $base = realpath(DIR_IMAGE . 'catalog/c2c/' . $seller_id);
            if (!$real || !$base || strpos($real, $base . DIRECTORY_SEPARATOR) !== 0 || !@getimagesize($real)) throw new \InvalidArgumentException('Ürün görseli doğrulanamadı.');
        }
        $lock = $this->lock('seller_' . $seller_id);
        try {
            $this->requireSeller($seller_id, true);
            if ($product_id) {
                if (!$this->getProduct($seller_id, $product_id)) throw new \InvalidArgumentException('Ürün bulunamadı veya bu mağazaya ait değil.');
                foreach (array('product_option','product_discount','product_special','product_recurring') as $table) {
                    if ($this->db->query("SELECT product_id FROM `" . DB_PREFIX . $table . "` WHERE product_id=" . $product_id . " LIMIT 1")->num_rows) throw new \InvalidArgumentException('Varyant, kampanya veya abonelik içeren bu ürün yönetici panelinden düzenlenmeli.');
                }
                // Disable first: MyISAM core tables cannot guarantee cross-table rollback.
                $this->db->query("UPDATE `" . DB_PREFIX . "product` SET status=0,date_modified=NOW() WHERE product_id=" . $product_id);
                $this->db->query("UPDATE `" . DB_PREFIX . "c2c_product` SET approval='pending',lead_time=" . (int)$lead_time . ",date_modified=NOW() WHERE product_id=" . $product_id . " AND seller_id=" . $seller_id);
                $this->db->query("UPDATE `" . DB_PREFIX . "product` SET model=" . $this->q($model) . ",price=" . $price . ",quantity=" . (int)$quantity . ",image=" . $this->q($image) . ",date_modified=NOW() WHERE product_id=" . $product_id);
            } else {
                $this->db->query("INSERT INTO `" . DB_PREFIX . "product` SET model=" . $this->q($model) . ",sku='',upc='',ean='',jan='',isbn='',mpn='',location='',quantity=" . (int)$quantity . ",stock_status_id=" . (int)$this->config->get('config_stock_status_id') . ",image=" . $this->q($image) . ",manufacturer_id=0,shipping=1,price=" . $price . ",points=0,tax_class_id=0,date_available=CURDATE(),weight=0,weight_class_id=" . (int)$this->config->get('config_weight_class_id') . ",length=0,width=0,height=0,length_class_id=" . (int)$this->config->get('config_length_class_id') . ",subtract=1,minimum=1,sort_order=0,status=0,viewed=0,date_added=NOW(),date_modified=NOW()");
                $product_id = (int)$this->db->getLastId();
                $this->db->query("INSERT INTO `" . DB_PREFIX . "c2c_product` SET product_id=" . $product_id . ",seller_id=" . $seller_id . ",approval='pending',lead_time=" . (int)$lead_time . ",date_added=NOW(),date_modified=NOW()");
                $this->db->query("INSERT INTO `" . DB_PREFIX . "product_to_store` SET product_id=" . $product_id . ",store_id=0");
            }
            // OpenCart decodes the stored description once before rendering. Encode
            // the generated safe HTML for that convention; never accept seller HTML.
            $safeHtml = nl2br(htmlspecialchars($description, ENT_QUOTES, 'UTF-8'));
            $storedDescription = htmlspecialchars($safeHtml, ENT_QUOTES, 'UTF-8');
            $languages = $this->db->query("SELECT language_id FROM `" . DB_PREFIX . "language` WHERE status=1")->rows;
            foreach ($languages as $language) {
                $language_id = (int)$language['language_id'];
                $this->db->query("DELETE FROM `" . DB_PREFIX . "product_description` WHERE product_id=" . $product_id . " AND language_id=" . $language_id);
                $this->db->query("INSERT INTO `" . DB_PREFIX . "product_description` SET product_id=" . $product_id . ",language_id=" . $language_id . ",name=" . $this->q($name) . ",description=" . $this->q($storedDescription) . ",tag='',meta_title=" . $this->q($name) . ",meta_description='',meta_keyword=''");
            }
            $this->db->query("DELETE FROM `" . DB_PREFIX . "product_to_category` WHERE product_id=" . $product_id);
            $this->db->query("INSERT INTO `" . DB_PREFIX . "product_to_category` SET product_id=" . $product_id . ",category_id=" . $category_id);
            $this->clearProductCache();
            return $product_id;
        } finally {
            $this->unlock($lock);
        }
    }

    public function approveProduct($product_id, $approval) {
        $this->enum($approval, array('pending','approved','rejected'));
        $map = $this->db->query("SELECT * FROM `" . DB_PREFIX . "c2c_product` WHERE product_id=" . (int)$product_id . " LIMIT 1")->row;
        if (!$map) throw new \InvalidArgumentException('Satıcı ürünü bulunamadı.');
        $inventoryLock = $this->lock('inventory');
        try {
            $lock = $this->lock('seller_' . (int)$map['seller_id']);
            try {
                if ($approval === 'approved') {
                    $setting = $this->db->query("SELECT `value` FROM `" . DB_PREFIX . "setting` WHERE store_id=0 AND `code`='module_c2c_marketplace' AND `key`='module_c2c_marketplace_status' LIMIT 1")->row;
                    if (!$this->isEnabled() || !$setting || (string)$setting['value'] !== '1') throw new \InvalidArgumentException('Ürün yayınlamak için önce pazaryeri modülünü etkinleştirin.');
                    $this->requireSeller($map['seller_id'], true);
                }
                $this->db->query("UPDATE `" . DB_PREFIX . "c2c_product` SET approval=" . $this->q($approval) . ",date_modified=NOW() WHERE product_id=" . (int)$product_id);
                $this->db->query("UPDATE `" . DB_PREFIX . "product` SET status=" . ($approval === 'approved' ? 1 : 0) . ",date_modified=NOW() WHERE product_id=" . (int)$product_id);
                $this->clearProductCache();
            } finally {
                $this->unlock($lock);
            }
        } finally {
            $this->unlock($inventoryLock);
        }
    }

    public function getModerationProducts($start = 0, $limit = 50) {
        return $this->decodeProducts($this->db->query($this->productSelect(true) . " JOIN `" . DB_PREFIX . "c2c_seller` s ON s.seller_id=cp.seller_id WHERE cp.approval='pending' ORDER BY cp.date_modified,p.product_id" . $this->limit($start, $limit))->rows);
    }

    public function recordOrder($order_id, $allocation = null) {
        $order_id = (int)$order_id;
        if ($order_id < 1) return;
        $lock = $this->lock('order_' . $order_id);
        try {
            $order = $this->db->query("SELECT order_id,currency_code,currency_value,store_id FROM `" . DB_PREFIX . "order` WHERE order_id=" . $order_id . " LIMIT 1")->row;
            if (!$order || (int)$order['store_id'] !== 0) return;
            $lines = $this->db->query("SELECT op.order_product_id,op.product_id,op.name,op.quantity,op.total,cp.seller_id FROM `" . DB_PREFIX . "order_product` op LEFT JOIN `" . DB_PREFIX . "c2c_product` cp ON cp.product_id=op.product_id WHERE op.order_id=" . $order_id . " ORDER BY op.order_product_id")->rows;
            $signature = $this->orderHash($lines);
            $state = $this->db->query("SELECT * FROM `" . DB_PREFIX . "c2c_order_state` WHERE order_id=" . $order_id . " LIMIT 1")->row;
            if ($state) {
                if (!hash_equals($state['snapshot_hash'], $signature)) {
                    $this->db->query("UPDATE `" . DB_PREFIX . "c2c_order_state` SET needs_review=1,date_modified=NOW() WHERE order_id=" . $order_id);
                }
                return;
            }
            $owned = array_filter($lines, function ($line) { return (int)$line['seller_id'] > 0; });
            if (!$owned) return;
            $promotion = $this->allocationForOrder($order_id, $lines, $allocation);
            $rate = $this->commissionRate();
            $this->db->query('START TRANSACTION');
            try {
                foreach ($owned as $index => $line) {
                    $total = number_format((float)$line['total'], 4, '.', '');
                    $discount = number_format(isset($promotion['discounts'][$index]) ? $promotion['discounts'][$index] : 0,4,'.','');
                    $eligible = number_format((float)$total-(float)$discount,4,'.','');
                    $this->db->query("INSERT INTO `" . DB_PREFIX . "c2c_order_item` SET order_product_id=" . (int)$line['order_product_id'] . ",order_id=" . $order_id . ",seller_id=" . (int)$line['seller_id'] . ",product_id=" . (int)$line['product_id'] . ",name=" . $this->q($line['name']) . ",quantity=" . (int)$line['quantity'] . ",total=" . $total . ",discount=" . $discount . ",eligible_total=" . $eligible . ",commission_rate=" . $rate . ",commission=ROUND(" . $eligible . "*" . $rate . "/100,4),net=" . $eligible . "-ROUND(" . $eligible . "*" . $rate . "/100,4),currency_code=" . $this->q($order['currency_code']) . ",currency_value=" . (float)$order['currency_value'] . ",base_currency_code=" . $this->q($this->baseCurrency()) . ",date_added=NOW()");
                }
                $this->db->query("INSERT INTO `" . DB_PREFIX . "c2c_order_state` SET order_id=" . $order_id . ",snapshot_hash=" . $this->q($signature) . ",needs_review=" . ($promotion['valid'] ? 0 : 1) . ",date_modified=NOW()");
                $this->db->query('COMMIT');
            } catch (\Throwable $e) {
                $this->db->query('ROLLBACK');
                throw $e;
            }
        } finally {
            $this->unlock($lock);
        }
    }

    public function isOrderSnapshotCurrent($order_id) {
        $order_id = (int)$order_id;
        $state = $this->db->query("SELECT * FROM `" . DB_PREFIX . "c2c_order_state` WHERE order_id=" . $order_id . " LIMIT 1")->row;
        if (!$state || (int)$state['needs_review']) return false;
        $lines = $this->db->query("SELECT order_product_id,product_id,quantity,total FROM `" . DB_PREFIX . "order_product` WHERE order_id=" . $order_id . " ORDER BY order_product_id")->rows;
        if (!hash_equals($state['snapshot_hash'], $this->orderHash($lines))) return false;
        $valid = $this->db->query("SELECT MIN(" . $this->validOrderSql() . ") AS valid_snapshot FROM `" . DB_PREFIX . "c2c_order_item` i JOIN `" . DB_PREFIX . "order` o ON o.order_id=i.order_id JOIN `" . DB_PREFIX . "c2c_order_state` st ON st.order_id=o.order_id WHERE i.order_id=" . $order_id)->row;
        return $valid && (int)$valid['valid_snapshot'] === 1;
    }

    public function getOrders($seller_id, $start = 0, $limit = 20) {
        $this->requireSeller($seller_id, false);
        return $this->db->query("SELECT o.order_id,o.date_added,o.currency_code,o.currency_value,COALESCE(os.name,'') AS status,SUM(i.total) AS total,SUM(i.discount) AS discount,SUM(i.eligible_total) AS eligible_total,SUM(i.commission) AS commission,SUM(i.net) AS net,COALESCE(sh.shipping_company,'') AS shipping_company,COALESCE(sh.tracking_number,'') AS tracking_number,MAX(NOT(" . $this->validOrderSql() . ")) AS needs_review FROM `" . DB_PREFIX . "c2c_order_item` i JOIN `" . DB_PREFIX . "order` o ON o.order_id=i.order_id JOIN `" . DB_PREFIX . "c2c_order_state` st ON st.order_id=o.order_id LEFT JOIN `" . DB_PREFIX . "order_status` os ON os.order_status_id=o.order_status_id AND os.language_id=" . $this->languageId() . " LEFT JOIN `" . DB_PREFIX . "c2c_shipment` sh ON sh.order_id=o.order_id AND sh.seller_id=i.seller_id WHERE i.seller_id=" . (int)$seller_id . " AND o.order_status_id>0 GROUP BY o.order_id,o.date_added,o.currency_code,o.currency_value,os.name,sh.shipping_company,sh.tracking_number ORDER BY o.order_id DESC" . $this->limit($start, $limit))->rows;
    }

    public function getOrder($seller_id, $order_id) {
        if ((int)$seller_id < 1 || (int)$order_id < 1) return array();
        $row = $this->db->query("SELECT o.order_id,o.firstname,o.lastname,o.shipping_address_1,o.shipping_address_2,o.shipping_city,o.shipping_postcode,o.shipping_country,o.date_added,o.currency_code,o.currency_value,COALESCE(os.name,'') AS status,st.needs_review,COALESCE(sh.shipping_company,'') AS shipping_company,COALESCE(sh.tracking_number,'') AS tracking_number FROM `" . DB_PREFIX . "order` o JOIN `" . DB_PREFIX . "c2c_order_state` st ON st.order_id=o.order_id LEFT JOIN `" . DB_PREFIX . "order_status` os ON os.order_status_id=o.order_status_id AND os.language_id=" . $this->languageId() . " LEFT JOIN `" . DB_PREFIX . "c2c_shipment` sh ON sh.order_id=o.order_id AND sh.seller_id=" . (int)$seller_id . " WHERE o.order_id=" . (int)$order_id . " AND o.order_status_id>0 AND EXISTS(SELECT 1 FROM `" . DB_PREFIX . "c2c_order_item` i WHERE i.order_id=o.order_id AND i.seller_id=" . (int)$seller_id . ") LIMIT 1")->row;
        if (!$row) return array();
        $row['items'] = $this->db->query("SELECT order_product_id,product_id,name,quantity,total,discount,eligible_total,commission_rate,commission,net FROM `" . DB_PREFIX . "c2c_order_item` WHERE seller_id=" . (int)$seller_id . " AND order_id=" . (int)$order_id . " ORDER BY id")->rows;
        $row['total'] = $row['discount'] = $row['eligible_total'] = $row['commission'] = $row['net'] = 0;
        foreach ($row['items'] as $item) {
            foreach (array('total','discount','eligible_total','commission','net') as $field) $row[$field] += (float)$item[$field];
        }
        foreach ($row['items'] as &$item) $item['name'] = html_entity_decode($item['name'], ENT_QUOTES, 'UTF-8');
        unset($item);
        $valid = $this->db->query("SELECT MIN(" . $this->validOrderSql() . ") AS valid_snapshot FROM `" . DB_PREFIX . "c2c_order_item` i JOIN `" . DB_PREFIX . "order` o ON o.order_id=i.order_id JOIN `" . DB_PREFIX . "c2c_order_state` st ON st.order_id=o.order_id WHERE i.seller_id=" . (int)$seller_id . " AND i.order_id=" . (int)$order_id)->row;
        if (!$valid || !(int)$valid['valid_snapshot']) $row['needs_review'] = 1;
        return $row;
    }

    public function saveShipment($seller_id, $order_id, $company, $tracking) {
        $this->requireSeller($seller_id, true);
        $order = $this->getOrder($seller_id, $order_id);
        if (!$order) throw new \InvalidArgumentException('Bu mağazaya ait sipariş bulunamadı.');
        if (!empty($order['needs_review'])) throw new \InvalidArgumentException('Sipariş değişmiş; kargo kaydından önce yönetici mutabakatı gerekli.');
        $company = $this->text($company, 100, 2, 'Kargo firması');
        $tracking = $this->text($tracking, 100, 2, 'Takip numarası');
        $this->db->query("INSERT INTO `" . DB_PREFIX . "c2c_shipment` SET seller_id=" . (int)$seller_id . ",order_id=" . (int)$order_id . ",shipping_company=" . $this->q($company) . ",tracking_number=" . $this->q($tracking) . ",date_modified=NOW() ON DUPLICATE KEY UPDATE shipping_company=VALUES(shipping_company),tracking_number=VALUES(tracking_number),date_modified=NOW()");
    }

    public function getStats($seller_id) {
        $this->requireSeller($seller_id, false);
        $seller_id = (int)$seller_id;
        $products = $this->db->query("SELECT COUNT(*) AS products,COALESCE(SUM(cp.approval='pending'),0) AS pending FROM `" . DB_PREFIX . "c2c_product` cp JOIN `" . DB_PREFIX . "product` p ON p.product_id=cp.product_id WHERE cp.seller_id=" . $seller_id)->row;
        $active = $this->db->query("SELECT COUNT(DISTINCT o.order_id) AS orders,COALESCE(SUM(i.total),0) AS gross,COALESCE(SUM(i.discount),0) AS discount,COALESCE(SUM(i.eligible_total),0) AS eligible_total,COALESCE(SUM(i.commission),0) AS commission,COALESCE(SUM(i.net),0) AS net FROM `" . DB_PREFIX . "c2c_order_item` i JOIN `" . DB_PREFIX . "order` o ON o.order_id=i.order_id JOIN `" . DB_PREFIX . "c2c_order_state` st ON st.order_id=o.order_id WHERE i.seller_id=" . $seller_id . " AND o.order_status_id>0 AND " . $this->validOrderSql())->row;
        $eligible = $this->db->query("SELECT COALESCE(SUM(i.net),0) AS net FROM `" . DB_PREFIX . "c2c_order_item` i JOIN `" . DB_PREFIX . "order` o ON o.order_id=i.order_id JOIN `" . DB_PREFIX . "c2c_order_state` st ON st.order_id=o.order_id WHERE i.seller_id=" . $seller_id . " AND o.order_status_id IN(" . $this->completeStatuses() . ") AND " . $this->validOrderSql())->row;
        $paid = $this->db->query("SELECT COALESCE(SUM(amount),0) AS paid FROM `" . DB_PREFIX . "c2c_settlement` WHERE seller_id=" . $seller_id . " AND currency_code=" . $this->q($this->baseCurrency()))->row;
        $held = $this->db->query("SELECT COUNT(DISTINCT i.order_id) AS held_orders FROM `" . DB_PREFIX . "c2c_order_item` i JOIN `" . DB_PREFIX . "order` o ON o.order_id=i.order_id JOIN `" . DB_PREFIX . "c2c_order_state` st ON st.order_id=o.order_id WHERE i.seller_id=" . $seller_id . " AND o.order_status_id>0 AND NOT(" . $this->validOrderSql() . ")")->row;
        return array_merge($products, $active, $held, array('paid'=>(float)$paid['paid'],'eligible_net'=>(float)$eligible['net'],'balance'=>round((float)$eligible['net']-(float)$paid['paid'], 4),'currency_code'=>$this->baseCurrency(),'currency'=>$this->baseCurrency()));
    }

    public function getLedger($seller_id, $start = 0, $limit = 50) {
        $this->requireSeller($seller_id, false);
        return $this->db->query("SELECT * FROM `" . DB_PREFIX . "c2c_settlement` WHERE seller_id=" . (int)$seller_id . " ORDER BY settlement_id DESC" . $this->limit($start, $limit))->rows;
    }

    public function getSettlements($start = 0, $limit = 50) {
        return $this->db->query("SELECT p.*,s.store_name FROM `" . DB_PREFIX . "c2c_settlement` p JOIN `" . DB_PREFIX . "c2c_seller` s ON s.seller_id=p.seller_id ORDER BY p.settlement_id DESC" . $this->limit($start, $limit))->rows;
    }

    public function addSettlement($seller_id, $amount, $reference, $admin_user_id) {
        $this->requireSeller($seller_id, true);
        $amount = $this->decimal($amount, 10, 2, true);
        $reference = $this->text($reference, 128, 3, 'Ödeme referansı');
        if ((int)$admin_user_id < 1) throw new \InvalidArgumentException('Geçerli yönetici oturumu gerekli.');
        $lock = $this->lock('settlement_' . (int)$seller_id);
        try {
            $this->db->query('START TRANSACTION');
            try {
                $stats = $this->getStats($seller_id);
                // Never round an entitlement up to allow paying more than earned.
                $available = floor(((float)$stats['balance'] + 0.0000001) * 100) / 100;
                if ((float)$amount > $available) throw new \InvalidArgumentException('Tutar tamamlanmış siparişlerin ödenebilir bakiyesini aşıyor.');
                if ($this->db->query("SELECT settlement_id FROM `" . DB_PREFIX . "c2c_settlement` WHERE seller_id=" . (int)$seller_id . " AND reference=" . $this->q($reference) . " LIMIT 1")->num_rows) throw new \InvalidArgumentException('Bu ödeme referansı daha önce kaydedilmiş.');
                $this->db->query("INSERT INTO `" . DB_PREFIX . "c2c_settlement` SET seller_id=" . (int)$seller_id . ",amount=" . $amount . ",currency_code=" . $this->q($this->baseCurrency()) . ",reference=" . $this->q($reference) . ",admin_user_id=" . (int)$admin_user_id . ",date_added=NOW()");
                $id = (int)$this->db->getLastId();
                $this->db->query('COMMIT');
                return $id;
            } catch (\Throwable $e) {
                $this->db->query('ROLLBACK');
                throw $e;
            }
        } finally {
            $this->unlock($lock);
        }
    }

    public function getPublicProducts($seller_id, $start = 0, $limit = 24) {
        return $this->decodeProducts($this->db->query($this->productSelect() . " JOIN `" . DB_PREFIX . "c2c_seller` s ON s.seller_id=cp.seller_id JOIN `" . DB_PREFIX . "product_to_store` ps ON ps.product_id=p.product_id AND ps.store_id=0 WHERE cp.seller_id=" . (int)$seller_id . " AND s.status='approved' AND cp.approval='approved' AND p.status=1 AND p.date_available<=CURDATE() ORDER BY p.product_id DESC" . $this->limit($start, $limit))->rows);
    }

    public function countPublicProducts($seller_id) {
        return (int)$this->db->query("SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "c2c_product` cp JOIN `" . DB_PREFIX . "product` p ON p.product_id=cp.product_id JOIN `" . DB_PREFIX . "c2c_seller` s ON s.seller_id=cp.seller_id JOIN `" . DB_PREFIX . "product_to_store` ps ON ps.product_id=p.product_id AND ps.store_id=0 WHERE cp.seller_id=" . (int)$seller_id . " AND s.status='approved' AND cp.approval='approved' AND p.status=1 AND p.date_available<=CURDATE()")->row['total'];
    }

    public function getSellerForProduct($product_id) {
        return $this->db->query("SELECT s.seller_id,s.store_name,s.slug,s.description,s.date_added,cp.lead_time FROM `" . DB_PREFIX . "c2c_seller` s JOIN `" . DB_PREFIX . "c2c_product` cp ON cp.seller_id=s.seller_id JOIN `" . DB_PREFIX . "product` p ON p.product_id=cp.product_id JOIN `" . DB_PREFIX . "product_to_store` ps ON ps.product_id=p.product_id AND ps.store_id=0 WHERE p.product_id=" . (int)$product_id . " AND s.status='approved' AND cp.approval='approved' AND p.status=1 AND p.date_available<=CURDATE() LIMIT 1")->row;
    }

    public function getQuestions($product_id) {
        if (!$this->getSellerForProduct($product_id)) return array();
        return $this->db->query("SELECT question_id,question,answer,date_added,date_answered FROM `" . DB_PREFIX . "c2c_question` WHERE product_id=" . (int)$product_id . " AND answer<>'' AND date_answered IS NOT NULL ORDER BY question_id DESC LIMIT 50")->rows;
    }

    public function askQuestion($product_id, $customer_id, $question) {
        $this->requireCustomer($customer_id);
        $seller = $this->getSellerForProduct($product_id);
        if (!$seller) throw new \InvalidArgumentException('Satıcı ürünü bulunamadı.');
        if ((int)$this->getSeller($seller['seller_id'])['customer_id'] === (int)$customer_id) throw new \InvalidArgumentException('Kendi ürününüze müşteri sorusu gönderemezsiniz.');
        $question = $this->text($question, 1000, 5, 'Soru');
        $lock = $this->lock('question_' . (int)$customer_id);
        try {
            $recent = $this->db->query("SELECT COUNT(*) AS total,COALESCE(MAX(date_added)>DATE_SUB(NOW(),INTERVAL 60 SECOND),0) AS too_soon FROM (SELECT date_added FROM `" . DB_PREFIX . "c2c_question` WHERE customer_id=" . (int)$customer_id . " AND date_added>DATE_SUB(NOW(),INTERVAL 1 HOUR) UNION ALL SELECT date_added FROM `" . DB_PREFIX . "c2c_store_question` WHERE customer_id=" . (int)$customer_id . " AND date_added>DATE_SUB(NOW(),INTERVAL 1 HOUR)) recent")->row;
            if ((int)$recent['too_soon'] || (int)$recent['total'] >= 5) throw new \InvalidArgumentException('Soru gönderim sınırına ulaştınız. Lütfen biraz sonra tekrar deneyin.');
            $this->db->query("INSERT INTO `" . DB_PREFIX . "c2c_question` SET product_id=" . (int)$product_id . ",seller_id=" . (int)$seller['seller_id'] . ",customer_id=" . (int)$customer_id . ",question=" . $this->q($question) . ",answer='',date_added=NOW(),date_answered=NULL");
            return (int)$this->db->getLastId();
        } finally {
            $this->unlock($lock);
        }
    }

    public function getSellerQuestions($seller_id) {
        $this->requireSeller($seller_id, false);
        return $this->decodeProducts($this->db->query("SELECT q.question_id,q.product_id,q.question,q.answer,q.date_added,q.date_answered,COALESCE(pd.name,'Silinmiş ürün') AS name FROM `" . DB_PREFIX . "c2c_question` q LEFT JOIN `" . DB_PREFIX . "product_description` pd ON pd.product_id=q.product_id AND pd.language_id=" . $this->languageId() . " WHERE q.seller_id=" . (int)$seller_id . " ORDER BY (q.answer='') DESC,q.question_id DESC LIMIT 100")->rows);
    }

    public function answerQuestion($seller_id, $question_id, $answer) {
        $this->requireSeller($seller_id, true);
        $answer = $this->text($answer, 2000, 1, 'Yanıt');
        $question = $this->db->query("SELECT question_id FROM `" . DB_PREFIX . "c2c_question` WHERE question_id=" . (int)$question_id . " AND seller_id=" . (int)$seller_id . " LIMIT 1")->row;
        if (!$question) throw new \InvalidArgumentException('Bu mağazaya ait soru bulunamadı.');
        $this->db->query("UPDATE `" . DB_PREFIX . "c2c_question` SET answer=" . $this->q($answer) . ",date_answered=NOW() WHERE question_id=" . (int)$question_id . " AND seller_id=" . (int)$seller_id);
    }

    private function productSelect($withSeller = false) {
        return "SELECT " . ($withSeller ? 's.store_name,' : '') . "p.product_id,p.model,p.price,p.quantity,p.image,p.status,cp.seller_id,cp.approval,cp.lead_time,pd.name,pd.description FROM `" . DB_PREFIX . "c2c_product` cp JOIN `" . DB_PREFIX . "product` p ON p.product_id=cp.product_id LEFT JOIN `" . DB_PREFIX . "product_description` pd ON pd.product_id=p.product_id AND pd.language_id=" . $this->languageId();
    }

    private function decodeProducts($rows) {
        foreach ($rows as &$row) {
            foreach (array('name','model') as $key) {
                if (isset($row[$key])) $row[$key] = html_entity_decode($row[$key], ENT_QUOTES, 'UTF-8');
            }
        }
        unset($row);
        return $rows;
    }

    private function validOrderSql() {
        // Check current order lines too: an admin edit must not silently leave a
        // previously snapshotted, larger entitlement available for payout.
        return "st.needs_review=0 AND i.base_currency_code=" . $this->q($this->baseCurrency()) . " AND NOT EXISTS(SELECT 1 FROM `" . DB_PREFIX . "c2c_order_item` ci LEFT JOIN `" . DB_PREFIX . "order_product` op ON op.order_product_id=ci.order_product_id AND op.order_id=ci.order_id WHERE ci.order_id=o.order_id AND (op.order_product_id IS NULL OR op.product_id<>ci.product_id OR op.quantity<>ci.quantity OR op.total<>ci.total)) AND NOT EXISTS(SELECT 1 FROM `" . DB_PREFIX . "order_product` np JOIN `" . DB_PREFIX . "c2c_product` cp ON cp.product_id=np.product_id LEFT JOIN `" . DB_PREFIX . "c2c_order_item` si ON si.order_product_id=np.order_product_id AND si.order_id=np.order_id WHERE np.order_id=o.order_id AND si.id IS NULL) AND NOT EXISTS(SELECT 1 FROM `" . DB_PREFIX . "return` rr JOIN `" . DB_PREFIX . "c2c_order_item` ri ON ri.order_id=rr.order_id AND ri.product_id=rr.product_id WHERE rr.order_id=o.order_id AND rr.customer_id=o.customer_id) AND ABS(COALESCE((SELECT SUM(di.discount) FROM `" . DB_PREFIX . "c2c_order_item` di WHERE di.order_id=o.order_id),0)+COALESCE((SELECT SUM(ot.value) FROM `" . DB_PREFIX . "order_total` ot WHERE ot.order_id=o.order_id AND ot.code='c2c_marketplace'),0))<0.00011";
    }

    private function allocationForOrder($order_id, $lines, $allocation) {
        $row = $this->db->query("SELECT COALESCE(SUM(`value`),0) AS adjustment FROM `" . DB_PREFIX . "order_total` WHERE order_id=" . (int)$order_id . " AND code='c2c_marketplace'")->row;
        $expected = round(-(float)$row['adjustment'],4);
        // Campaign calculation may be intentionally suppressed by coupons/reward
        // totals. If no C2C total was charged, no seller-funded discount is due.
        if (abs($expected) < 0.00001) return array('valid'=>true,'discounts'=>array());
        $invalid = array('valid'=>false,'discounts'=>array());
        if ($expected < 0 || !is_array($allocation) || !isset($allocation['discount'],$allocation['lines']) || !is_numeric($allocation['discount']) || !is_finite((float)$allocation['discount']) || abs((float)$allocation['discount']-$expected)>0.00011 || !is_array($allocation['lines'])) return $invalid;
        $discounts = array();
        $sum = 0.0;
        foreach ($allocation['lines'] as $allocated) {
            if (!is_array($allocated) || !isset($allocated['index'],$allocated['product_id'],$allocated['discount']) || !is_scalar($allocated['index']) || !preg_match('/^(?:0|[1-9][0-9]*)$/D',(string)$allocated['index']) || !is_numeric($allocated['discount']) || !is_finite((float)$allocated['discount'])) return $invalid;
            $index = (int)$allocated['index'];
            $discount = round((float)$allocated['discount'],4);
            if (!isset($lines[$index]) || isset($discounts[$index]) || (int)$lines[$index]['product_id'] !== (int)$allocated['product_id'] || (int)$lines[$index]['seller_id']<1 || $discount<0 || $discount>(float)$lines[$index]['total']+0.00001) return $invalid;
            $discounts[$index] = $discount;
            $sum += $discount;
        }
        if (abs($sum-$expected)>0.00011) return $invalid;
        return array('valid'=>true,'discounts'=>$discounts);
    }

    private function orderHash($lines) {
        $signature = array();
        foreach ($lines as $line) {
            $signature[] = array((int)$line['order_product_id'],(int)$line['product_id'],(int)$line['quantity'],number_format((float)$line['total'],4,'.',''));
        }
        return hash('sha256', json_encode($signature));
    }

    private function completeStatuses() {
        $statuses = $this->config->get('config_complete_status');
        if (!is_array($statuses)) $statuses = array();
        $statuses = array_unique(array_filter(array_map('intval', $statuses), function ($id) { return $id > 0; }));
        return $statuses ? implode(',', $statuses) : '-1';
    }

    private function baseCurrency() {
        $currency = (string)$this->config->get('config_currency');
        if (!preg_match('/^[A-Z]{3}$/D', $currency)) throw new \RuntimeException('Mağazanın ana para birimi yapılandırılmalı.');
        return $currency;
    }

    private function commissionRate() {
        $rate = $this->config->get('module_c2c_marketplace_commission');
        if ($rate === null || $rate === '') $rate = '10';
        if (!is_scalar($rate) || !preg_match('/^(?:[0-9]{1,3})(?:\.[0-9]{1,4})?$/D', (string)$rate) || (float)$rate > 100) throw new \RuntimeException('Komisyon oranı 0–100 arasında olmalı.');
        return number_format((float)$rate, 4, '.', '');
    }

    private function sellerFields($data) {
        if (!is_array($data)) throw new \InvalidArgumentException('Geçersiz mağaza bilgisi.');
        $fields = array();
        foreach (array('store_name'=>array(100,2,'Mağaza adı'),'description'=>array(2000,0,'Mağaza açıklaması'),'phone'=>array(32,0,'Telefon'),'legal_name'=>array(160,0,'Yasal unvan')) as $key=>$rule) {
            $fields[$key] = $this->text(isset($data[$key]) ? $data[$key] : '', $rule[0], $rule[1], $rule[2]);
        }
        return $fields;
    }

    private function requireSeller($seller_id, $approved) {
        $seller = $this->getSeller($seller_id);
        if (!$seller) throw new \InvalidArgumentException('Mağaza bulunamadı.');
        if ($approved && $seller['status'] !== 'approved') throw new \InvalidArgumentException('Bu işlem için mağaza onayı gerekli.');
        return $seller;
    }

    private function requireCustomer($customer_id) {
        if ((int)$customer_id < 1) throw new \InvalidArgumentException('Müşteri oturumu gerekli.');
        $customer = $this->db->query("SELECT customer_id FROM `" . DB_PREFIX . "customer` c WHERE c.customer_id=" . (int)$customer_id . " AND c.status=1 AND c.store_id=0 AND NOT EXISTS(SELECT 1 FROM `" . DB_PREFIX . "customer_approval` ca WHERE ca.customer_id=c.customer_id AND ca.type='customer') LIMIT 1")->row;
        if (!$customer) throw new \InvalidArgumentException('Aktif ve onaylı müşteri hesabı gerekli.');
    }

    private function text($value, $max, $min, $label) {
        if (!is_scalar($value)) throw new \InvalidArgumentException($label . ' geçersiz.');
        $value = trim(strip_tags(html_entity_decode((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8')));
        if (!preg_match('//u', $value) || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', $value)) throw new \InvalidArgumentException($label . ' geçersiz karakter içeriyor.');
        $length = $this->length($value);
        if ($length < $min || $length > $max) throw new \InvalidArgumentException($label . ' ' . $min . '–' . $max . ' karakter olmalı.');
        return $value;
    }

    private function length($value) {
        return function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : preg_match_all('/./us', $value);
    }

    private function decimal($value, $integerDigits, $scale, $positive) {
        if (!is_scalar($value) || !preg_match('/^(?:0|[1-9][0-9]{0,' . ($integerDigits-1) . '})(?:\.[0-9]{1,' . $scale . '})?$/D', (string)$value)) throw new \InvalidArgumentException('Tutar geçersiz; noktalı ondalık biçimi kullanın.');
        if ($positive && (float)$value <= 0) throw new \InvalidArgumentException('Tutar sıfırdan büyük olmalı.');
        return number_format((float)$value, $scale, '.', '');
    }

    private function enum($value, $allowed) {
        if (!is_string($value) || !in_array($value, $allowed, true)) throw new \InvalidArgumentException('Geçersiz durum seçimi.');
    }

    private function languageId() {
        return max(1, (int)$this->config->get('config_language_id'));
    }

    private function q($value) {
        return "'" . $this->db->escape((string)$value) . "'";
    }

    private function limit($start, $limit) {
        return ' LIMIT ' . max(0,(int)$start) . ',' . min(100,max(1,(int)$limit));
    }

    private function lock($suffix) {
        $name = 'c2c_' . substr(hash('sha256', DB_PREFIX . $suffix),0,58);
        $row = $this->db->query('SELECT GET_LOCK(' . $this->q($name) . ',5) AS acquired')->row;
        if (!isset($row['acquired']) || (int)$row['acquired'] !== 1) throw new \RuntimeException('İşlem şu anda meşgul. Lütfen tekrar deneyin.');
        return $name;
    }

    private function unlock($name) {
        $this->db->query('SELECT RELEASE_LOCK(' . $this->q($name) . ')');
    }

    private function clearProductCache() {
        if ($this->cache) $this->cache->delete('product');
    }

    private function ensureColumn($table, $column, $definition) {
        if ($this->db->query('SHOW COLUMNS FROM `' . DB_PREFIX . $table . '` LIKE ' . $this->q($column))->num_rows) return false;
        $this->db->query('ALTER TABLE `' . DB_PREFIX . $table . '` ADD `' . $column . '` ' . $definition);
        return true;
    }
}
