<?php
namespace C2c\Payment;

/**
 * Pure PayTR platform transfer builder and payment-notification verifier.
 * No transport, automatic payout, webhook route or replay handler is exposed.
 * Verified payment callbacks still need persisted order/amount/idempotency checks.
 */
final class Paytr {
    private $merchantId;
    private $merchantKey;
    private $merchantSalt;

    public function __construct($merchantId, $merchantKey, $merchantSalt) {
        if (!is_string($merchantId) || !preg_match('/^[0-9]{1,20}$/D', $merchantId)) throw new \InvalidArgumentException('PayTR mağaza numarası geçersiz.');
        $this->merchantId = $merchantId;
        $this->merchantKey = $this->credential($merchantKey);
        $this->merchantSalt = $this->credential($merchantSalt);
    }

    /** Amount arguments are integer kurus strings, NOT TL and NOT floats. */
    public function buildTransfer($merchantOrderId, $transactionId, $submerchantAmount, $totalAmount, $accountName, $iban) {
        $order = $this->identifier($merchantOrderId, 64);
        $transaction = $this->identifier($transactionId, 60);
        $sub = $this->amount($submerchantAmount);
        $total = $this->amount($totalAmount);
        if ($sub > $total) throw new \InvalidArgumentException('Satıcı transferi toplam tutarı aşamaz.');
        if (!is_string($accountName) || !preg_match('//u', $accountName) || mb_strlen($accountName, 'UTF-8') < 2 || mb_strlen($accountName, 'UTF-8') > 100 || trim($accountName) !== $accountName || preg_match('/[\x00-\x1F\x7F]/', $accountName)) throw new \InvalidArgumentException('Hesap sahibi unvanı geçersiz.');
        if (!is_string($iban) || !$this->validTurkishIban($iban)) throw new \InvalidArgumentException('Geçerli, boşluksuz TR IBAN gerekli.');
        $fields = array('merchant_id' => $this->merchantId, 'merchant_oid' => $order,
            'trans_id' => $transaction, 'submerchant_amount' => $submerchantAmount,
            'total_amount' => $totalAmount, 'transfer_name' => $accountName, 'transfer_iban' => $iban);
        $material = $this->merchantId . $order . $transaction . $submerchantAmount . $totalAmount . $accountName . $iban . $this->merchantSalt;
        $fields['paytr_token'] = base64_encode(hash_hmac('sha256', $material, $this->merchantKey, true));
        return array('method' => 'POST', 'url' => 'https://www.paytr.com/odeme/platform/transfer', 'fields' => $fields);
    }

    /** Verifies payment callback HMAC only; does NOT mark an order paid. */
    public function verifyPaymentNotification(array $notification) {
        foreach (array('merchant_oid', 'status', 'total_amount', 'hash') as $key) {
            if (!isset($notification[$key]) || !is_string($notification[$key])) return false;
        }
        if (!preg_match('/^[a-zA-Z0-9]{1,64}$/D', $notification['merchant_oid']) || !in_array($notification['status'], array('success', 'failed'), true) || !preg_match('/^(0|[1-9][0-9]{0,11})$/D', $notification['total_amount'])) return false;
        $expected = base64_encode(hash_hmac('sha256', $notification['merchant_oid'] . $this->merchantSalt . $notification['status'] . $notification['total_amount'], $this->merchantKey, true));
        return hash_equals($expected, $notification['hash']);
    }

    private function validTurkishIban($iban) {
        if (!preg_match('/^TR[0-9]{24}$/D', $iban)) return false;
        $digits = substr($iban, 4) . '2927' . substr($iban, 2, 2);
        $remainder = 0;
        for ($i = 0, $length = strlen($digits); $i < $length; $i++) $remainder = ($remainder * 10 + (int)$digits[$i]) % 97;
        return $remainder === 1;
    }

    private function amount($value) {
        if (!is_string($value) || !preg_match('/^[1-9][0-9]{0,11}$/D', $value)) throw new \InvalidArgumentException('PayTR tutarı pozitif tam kuruş metni olmalı.');
        return (int)$value;
    }

    private function identifier($value, $max) {
        if (!is_string($value) || !preg_match('/^[a-zA-Z0-9]{1,' . $max . '}$/D', $value)) throw new \InvalidArgumentException('PayTR sipariş/transfer referansı alfanumerik olmalı.');
        return $value;
    }

    private function credential($value) {
        if (!is_string($value) || $value === '' || strlen($value) > 1024 || preg_match('/[\x00-\x20\x7F]/', $value)) throw new \InvalidArgumentException('PayTR API kimlik bilgisi eksik veya geçersiz.');
        return $value;
    }
}
