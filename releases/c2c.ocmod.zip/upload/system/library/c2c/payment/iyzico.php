<?php
namespace C2c\Payment;

/**
 * Pure iyzico marketplace request builder; never sends money or HTTP requests.
 * The checkout integration must persist authenticated paymentTransactionId and
 * subMerchantKey mappings before using these requests. Never log returned data.
 */
final class Iyzico {
    private $apiKey;
    private $secretKey;
    private $baseUrl;

    public function __construct($apiKey, $secretKey, $sandbox = true) {
        $this->apiKey = $this->credential($apiKey);
        $this->secretKey = $this->credential($secretKey);
        $this->baseUrl = $sandbox ? 'https://sandbox-api.iyzipay.com' : 'https://api.iyzipay.com';
    }

    public function buildApproval($paymentTransactionId, $conversationId, $nonce = null) {
        return $this->build('/payment/iyzipos/item/approve', $paymentTransactionId, $conversationId, $nonce);
    }

    public function buildDisapproval($paymentTransactionId, $conversationId, $nonce = null) {
        return $this->build('/payment/iyzipos/item/disapprove', $paymentTransactionId, $conversationId, $nonce);
    }

    /** Add marketplace fields to one already-priced iyzico basket item. */
    public function assignSubMerchant(array $basketItem, $subMerchantKey, $subMerchantPrice) {
        if (!isset($basketItem['price']) || !is_string($basketItem['price'])) {
            throw new \InvalidArgumentException('iyzico kalem fiyatını noktalı ondalık metin olarak sağlayın.');
        }
        $price = $this->minor($basketItem['price']);
        $net = $this->minor($subMerchantPrice);
        if ($net > $price) throw new \InvalidArgumentException('Alt üye tutarı kalem fiyatını aşamaz.');
        $key = $this->identifier($subMerchantKey, 256, 'Alt üye anahtarı');
        $basketItem['subMerchantKey'] = $key;
        $basketItem['subMerchantPrice'] = number_format($net / 100, 2, '.', '');
        return $basketItem;
    }

    private function build($path, $transactionId, $conversationId, $nonce) {
        $transactionId = $this->identifier($transactionId, 64, 'Ödeme işlem referansı');
        if (!preg_match('/^[0-9]+$/D', $transactionId)) throw new \InvalidArgumentException('iyzico paymentTransactionId sayısal olmalı.');
        $conversationId = $this->identifier($conversationId, 128, 'Konuşma referansı');
        if ($nonce === null) $nonce = bin2hex(random_bytes(16));
        if (!is_string($nonce) || !preg_match('/^[a-zA-Z0-9_-]{16,128}$/D', $nonce)) throw new \InvalidArgumentException('Geçerli rastgele istek anahtarı gerekli.');
        // Match official CreateApprovalRequest parent field order and exact JSON.
        $payload = array('locale' => 'tr', 'conversationId' => $conversationId, 'paymentTransactionId' => $transactionId);
        $body = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        $signature = hash_hmac('sha256', $nonce . $path . $body, $this->secretKey);
        $authorization = 'IYZWSv2 ' . base64_encode('apiKey:' . $this->apiKey . '&randomKey:' . $nonce . '&signature:' . $signature);
        return array('method' => 'POST', 'url' => $this->baseUrl . $path,
            'headers' => array('Accept: application/json', 'Content-Type: application/json', 'Authorization: ' . $authorization),
            'body' => $body);
    }

    private function minor($value) {
        if (!is_string($value) || !preg_match('/^(0|[1-9][0-9]{0,7})(?:\.([0-9]{1,2}))?$/D', $value, $parts)) {
            throw new \InvalidArgumentException('iyzico tutarı en çok iki ondalık basamakla noktalı metin olmalı.');
        }
        return ((int)$parts[1] * 100) + (int)str_pad(isset($parts[2]) ? $parts[2] : '', 2, '0');
    }

    private function credential($value) {
        if (!is_string($value) || $value === '' || strlen($value) > 1024 || preg_match('/[\x00-\x20\x7F]/', $value)) throw new \InvalidArgumentException('iyzico API kimlik bilgisi eksik veya geçersiz.');
        return $value;
    }

    private function identifier($value, $max, $label) {
        if (!is_string($value) || strlen($value) < 1 || strlen($value) > $max || preg_match('/[\x00-\x20\x7F]/', $value)) throw new \InvalidArgumentException($label . ' geçersiz.');
        return $value;
    }
}
