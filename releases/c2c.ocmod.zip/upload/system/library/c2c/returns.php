<?php
namespace C2c;

/** Read-only native returns scoped to approved seller, order owner and product. */
final class Returns {
    private $db;
    private $config;

    public function __construct($registry) {
        $this->db = $registry->get('db');
        $this->config = $registry->get('config');
    }

    public function getReturns($seller_id, $start = 0, $limit = 20) {
        $seller_id = $this->id($seller_id);
        if (!$seller_id || !$this->enabled()) return array();
        $start = is_scalar($start) ? max(0, min(1000000, (int)$start)) : 0;
        $limit = is_scalar($limit) ? max(1, min(100, (int)$limit)) : 20;
        $rows = $this->db->query($this->select($seller_id) . ' ORDER BY r.return_id DESC LIMIT ' . $start . ',' . $limit)->rows;
        return $this->decode($rows);
    }

    public function getReturn($seller_id, $return_id) {
        $seller_id = $this->id($seller_id);
        $return_id = $this->id($return_id);
        if (!$seller_id || !$return_id || !$this->enabled()) return array();
        $rows = $this->db->query($this->select($seller_id) . ' AND r.return_id=' . $return_id . ' LIMIT 1')->rows;
        $rows = $this->decode($rows);
        return $rows ? $rows[0] : array();
    }

    private function select($seller_id) {
        $language_id = max(0, (int)$this->config->get('config_language_id'));
        return "SELECT DISTINCT r.return_id,r.order_id,r.product_id,r.product,r.model,r.quantity,o.firstname,r.opened,r.comment,r.date_ordered,r.date_added,r.date_modified,"
            . "COALESCE(rr.name,'') AS reason,COALESCE(rs.name,'') AS status,COALESCE(ra.name,'') AS action "
            . "FROM `" . DB_PREFIX . "return` r "
            . "JOIN `" . DB_PREFIX . "order` o ON o.order_id=r.order_id AND o.store_id=0 AND o.order_status_id>0 AND o.customer_id=r.customer_id AND o.customer_id>0 "
            . "JOIN `" . DB_PREFIX . "c2c_order_item` oi ON oi.order_id=r.order_id AND oi.product_id=r.product_id AND oi.seller_id=" . (int)$seller_id . " "
            . "JOIN `" . DB_PREFIX . "c2c_seller` s ON s.seller_id=oi.seller_id AND s.status='approved' "
            . "LEFT JOIN `" . DB_PREFIX . "return_reason` rr ON rr.return_reason_id=r.return_reason_id AND rr.language_id=" . $language_id . " "
            . "LEFT JOIN `" . DB_PREFIX . "return_status` rs ON rs.return_status_id=r.return_status_id AND rs.language_id=" . $language_id . " "
            . "LEFT JOIN `" . DB_PREFIX . "return_action` ra ON ra.return_action_id=r.return_action_id AND ra.language_id=" . $language_id . " "
            . "WHERE r.quantity>0 AND EXISTS (SELECT 1 FROM `" . DB_PREFIX . "order_product` op WHERE op.order_id=r.order_id AND op.product_id=r.product_id)";
    }

    private function decode(array $rows) {
        foreach ($rows as &$row) {
            // Native Request::clean stores HTML entities; custom Twig escapes
            // these decoded strings exactly once. No HTML is generated here.
            foreach (array('product','model','firstname','comment','reason','status','action') as $key) {
                $row[$key] = html_entity_decode((string)$row[$key], ENT_QUOTES, 'UTF-8');
            }
            foreach (array('return_id','order_id','product_id','quantity','opened') as $key) $row[$key] = (int)$row[$key];
        }
        unset($row);
        return $rows;
    }

    private function id($value) {
        if ((!is_string($value) && !is_int($value)) || !preg_match('/^[0-9]{1,10}$/D', (string)$value)) return 0;
        $id = (int)$value;
        return $id > 0 && $id <= 4294967295 ? $id : 0;
    }

    private function enabled() {
        return (bool)$this->config->get('module_c2c_marketplace_status') && (int)$this->config->get('config_store_id') === 0;
    }
}
