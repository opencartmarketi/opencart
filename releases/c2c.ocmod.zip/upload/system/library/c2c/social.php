<?php
namespace C2c;

/** Customer-to-store relationships and verified-purchase social content. */
class Social {
    private $db;
    private $config;
    private $marketplace;

    public function __construct($registry) {
        $this->db = $registry->get('db');
        $this->config = $registry->get('config');
        require_once __DIR__ . '/marketplace.php';
        $this->marketplace = new Marketplace($registry);
    }

    public function install() {
        $schemas = array(
            'c2c_follow' => "seller_id INT UNSIGNED NOT NULL,customer_id INT NOT NULL,date_added DATETIME NOT NULL,PRIMARY KEY(seller_id,customer_id),KEY customer_id(customer_id)",
            'c2c_review' => "review_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,seller_id INT UNSIGNED NOT NULL,customer_id INT NOT NULL,order_id INT NOT NULL,rating TINYINT UNSIGNED NOT NULL,text TEXT NOT NULL,status TINYINT NOT NULL DEFAULT 1,date_added DATETIME NOT NULL,PRIMARY KEY(review_id),UNIQUE KEY seller_customer(seller_id,customer_id),KEY seller_date(seller_id,date_added),KEY order_id(order_id)",
            'c2c_store_question' => "question_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,seller_id INT UNSIGNED NOT NULL,customer_id INT NOT NULL,question TEXT NOT NULL,answer TEXT NOT NULL,date_added DATETIME NOT NULL,date_answered DATETIME DEFAULT NULL,PRIMARY KEY(question_id),KEY seller_date(seller_id,date_added),KEY customer_date(customer_id,date_added)"
        );
        foreach ($schemas as $table=>$schema) $this->db->query('CREATE TABLE IF NOT EXISTS `' . DB_PREFIX . $table . '` (' . $schema . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
    }

    public function isFollowing($seller_id, $customer_id) {
        if ((int)$seller_id < 1 || (int)$customer_id < 1) return false;
        return (bool)$this->db->query("SELECT f.seller_id FROM `" . DB_PREFIX . "c2c_follow` f JOIN `" . DB_PREFIX . "c2c_seller` s ON s.seller_id=f.seller_id JOIN `" . DB_PREFIX . "customer` c ON c.customer_id=f.customer_id WHERE f.seller_id=" . (int)$seller_id . " AND f.customer_id=" . (int)$customer_id . " AND s.status='approved' AND s.customer_id<>c.customer_id AND c.status=1 AND c.store_id=0 AND NOT EXISTS(SELECT 1 FROM `" . DB_PREFIX . "customer_approval` ca WHERE ca.customer_id=c.customer_id AND ca.type='customer') LIMIT 1")->num_rows;
    }

    public function follow($seller_id, $customer_id, $follow) {
        $this->requireEnabled();
        $this->customer($customer_id);
        $seller = $this->seller($seller_id);
        if ((int)$seller['customer_id'] === (int)$customer_id) throw new \InvalidArgumentException('Kendi mağazanızı takip edemezsiniz.');
        if (!is_bool($follow) && !in_array($follow,array(0,1,'0','1'),true)) throw new \InvalidArgumentException('Takip seçimi geçersiz.');
        if ((bool)$follow) {
            $this->db->query("INSERT IGNORE INTO `" . DB_PREFIX . "c2c_follow` SET seller_id=" . (int)$seller_id . ",customer_id=" . (int)$customer_id . ",date_added=NOW()");
        } else {
            $this->db->query("DELETE FROM `" . DB_PREFIX . "c2c_follow` WHERE seller_id=" . (int)$seller_id . " AND customer_id=" . (int)$customer_id);
        }
        return $this->isFollowing($seller_id, $customer_id);
    }

    public function getFollowerCount($seller_id) {
        if (!$this->marketplace->getSeller($seller_id,true)) return 0;
        return (int)$this->db->query("SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "c2c_follow` f JOIN `" . DB_PREFIX . "customer` c ON c.customer_id=f.customer_id JOIN `" . DB_PREFIX . "c2c_seller` s ON s.seller_id=f.seller_id WHERE f.seller_id=" . (int)$seller_id . " AND c.status=1 AND c.store_id=0 AND c.customer_id<>s.customer_id AND NOT EXISTS(SELECT 1 FROM `" . DB_PREFIX . "customer_approval` ca WHERE ca.customer_id=c.customer_id AND ca.type='customer')")->row['total'];
    }

    public function addReview($seller_id, $customer_id, $data) {
        $this->requireEnabled();
        $this->customer($customer_id);
        $seller = $this->seller($seller_id);
        if ((int)$seller['customer_id'] === (int)$customer_id) throw new \InvalidArgumentException('Kendi mağazanızı değerlendiremezsiniz.');
        if (!is_array($data)) throw new \InvalidArgumentException('Değerlendirme bilgisi geçersiz.');
        $order_id = isset($data['order_id']) && is_scalar($data['order_id']) ? (string)$data['order_id'] : '';
        $rating = isset($data['rating']) && is_scalar($data['rating']) ? (string)$data['rating'] : '';
        if (!preg_match('/^[1-9][0-9]*$/D',$order_id) || !preg_match('/^[1-5]$/D',$rating)) throw new \InvalidArgumentException('Geçerli sipariş ve 1–5 arasında puan seçin.');
        $text = $this->text(isset($data['text']) ? $data['text'] : '',20,2000,'Değerlendirme');
        $lock = $this->lock('review_' . (int)$seller_id . '_' . (int)$customer_id);
        try {
            if ($this->db->query("SELECT review_id FROM `" . DB_PREFIX . "c2c_review` WHERE seller_id=" . (int)$seller_id . " AND customer_id=" . (int)$customer_id . " LIMIT 1")->num_rows) throw new \InvalidArgumentException('Bu mağazayı daha önce değerlendirdiniz.');
            if (!$this->reviewableOrder($seller_id,$customer_id,(int)$order_id)) throw new \InvalidArgumentException('Yalnızca size ait tamamlanmış ve iadesiz mağaza siparişini değerlendirebilirsiniz.');
            $this->db->query("INSERT INTO `" . DB_PREFIX . "c2c_review` SET seller_id=" . (int)$seller_id . ",customer_id=" . (int)$customer_id . ",order_id=" . (int)$order_id . ",rating=" . (int)$rating . ",text=" . $this->q($text) . ",status=1,date_added=NOW()");
            return (int)$this->db->getLastId();
        } finally {
            $this->unlock($lock);
        }
    }

    public function getReviews($seller_id, $start = 0, $limit = 20) {
        if (!$this->marketplace->getSeller($seller_id,true)) return array();
        $start = max(0,(int)$start);
        $limit = min(100,max(1,(int)$limit));
        $visible = array();
        $skipped = 0;
        foreach ($this->reviewCandidates($seller_id) as $row) {
            if (!$this->marketplace->isOrderSnapshotCurrent($row['order_id'])) continue;
            if ($skipped++ < $start) continue;
            $visible[] = array('review_id'=>(int)$row['review_id'],'rating'=>(int)$row['rating'],'text'=>$row['text'],'date_added'=>$row['date_added'],'firstname'=>html_entity_decode($row['firstname'],ENT_QUOTES,'UTF-8'),'verified'=>true);
            if (count($visible) >= $limit) break;
        }
        return $visible;
    }

    public function getRating($seller_id) {
        if (!$this->marketplace->getSeller($seller_id,true)) return array('rating'=>0.0,'total'=>0);
        $sum = 0;
        $count = 0;
        foreach ($this->reviewCandidates($seller_id) as $row) {
            if (!$this->marketplace->isOrderSnapshotCurrent($row['order_id'])) continue;
            $sum += (int)$row['rating'];
            $count++;
        }
        return array('rating'=>$count ? round($sum/$count,2) : 0.0,'total'=>$count);
    }

    public function getReviewableOrders($seller_id, $customer_id) {
        if ((int)$customer_id < 1 || !$this->marketplace->getSeller($seller_id,true)) return array();
        $seller = $this->marketplace->getSeller($seller_id);
        if ((int)$seller['customer_id'] === (int)$customer_id) return array();
        $this->customer($customer_id);
        if ($this->db->query("SELECT review_id FROM `" . DB_PREFIX . "c2c_review` WHERE seller_id=" . (int)$seller_id . " AND customer_id=" . (int)$customer_id . " LIMIT 1")->num_rows) return array();
        $candidates = $this->db->query("SELECT o.order_id,o.date_added FROM `" . DB_PREFIX . "order` o WHERE o.customer_id=" . (int)$customer_id . " AND o.store_id=0 AND o.order_status_id IN(" . $this->completeStatuses() . ") AND EXISTS(SELECT 1 FROM `" . DB_PREFIX . "c2c_order_item` i WHERE i.order_id=o.order_id AND i.seller_id=" . (int)$seller_id . ") ORDER BY o.order_id DESC LIMIT 100")->rows;
        $valid = array();
        foreach ($candidates as $row) if ($this->marketplace->isOrderSnapshotCurrent($row['order_id'])) $valid[] = array('order_id'=>(int)$row['order_id'],'date_added'=>$row['date_added']);
        return $valid;
    }

    public function askStoreQuestion($seller_id, $customer_id, $text) {
        $this->requireEnabled();
        $this->customer($customer_id);
        $seller = $this->seller($seller_id);
        if ((int)$seller['customer_id'] === (int)$customer_id) throw new \InvalidArgumentException('Kendi mağazanıza müşteri sorusu gönderemezsiniz.');
        $text = $this->text($text,5,1000,'Soru');
        $lock = $this->lock('question_' . (int)$customer_id);
        try {
            $recent = $this->db->query("SELECT COUNT(*) AS total,COALESCE(MAX(date_added)>DATE_SUB(NOW(),INTERVAL 60 SECOND),0) AS too_soon FROM (SELECT date_added FROM `" . DB_PREFIX . "c2c_store_question` WHERE customer_id=" . (int)$customer_id . " AND date_added>DATE_SUB(NOW(),INTERVAL 1 HOUR) UNION ALL SELECT date_added FROM `" . DB_PREFIX . "c2c_question` WHERE customer_id=" . (int)$customer_id . " AND date_added>DATE_SUB(NOW(),INTERVAL 1 HOUR)) recent")->row;
            if ((int)$recent['too_soon'] || (int)$recent['total'] >= 5) throw new \InvalidArgumentException('Soru gönderim sınırına ulaştınız. Lütfen biraz sonra tekrar deneyin.');
            $this->db->query("INSERT INTO `" . DB_PREFIX . "c2c_store_question` SET seller_id=" . (int)$seller_id . ",customer_id=" . (int)$customer_id . ",question=" . $this->q($text) . ",answer='',date_added=NOW(),date_answered=NULL");
            return (int)$this->db->getLastId();
        } finally {
            $this->unlock($lock);
        }
    }

    public function getStoreQuestions($seller_id, $answeredOnly = true, $start = 0, $limit = 30) {
        if (!$this->marketplace->getSeller($seller_id,true)) return array();
        $rows = $this->db->query("SELECT q.question_id,q.seller_id,q.customer_id,q.question,q.answer,q.date_added,q.date_answered,c.firstname FROM `" . DB_PREFIX . "c2c_store_question` q JOIN `" . DB_PREFIX . "customer` c ON c.customer_id=q.customer_id WHERE q.seller_id=" . (int)$seller_id . " AND c.status=1" . ($answeredOnly ? " AND q.answer<>'' AND q.date_answered IS NOT NULL" : '') . " ORDER BY q.question_id DESC LIMIT " . max(0,(int)$start) . ',' . min(100,max(1,(int)$limit)))->rows;
        foreach ($rows as &$row) {
            $row['firstname'] = html_entity_decode($row['firstname'],ENT_QUOTES,'UTF-8');
            if ($answeredOnly) unset($row['customer_id'],$row['seller_id']);
        }
        unset($row);
        return $rows;
    }

    public function answerStoreQuestion($seller_id, $question_id, $answer) {
        $this->requireEnabled();
        $this->seller($seller_id);
        $answer = $this->text($answer,2,2000,'Yanıt');
        $row = $this->db->query("SELECT question_id FROM `" . DB_PREFIX . "c2c_store_question` WHERE question_id=" . (int)$question_id . " AND seller_id=" . (int)$seller_id . " LIMIT 1")->row;
        if (!$row) throw new \InvalidArgumentException('Bu mağazaya ait soru bulunamadı.');
        $this->db->query("UPDATE `" . DB_PREFIX . "c2c_store_question` SET answer=" . $this->q($answer) . ",date_answered=NOW() WHERE question_id=" . (int)$question_id . " AND seller_id=" . (int)$seller_id);
    }

    private function reviewCandidates($seller_id) {
        return $this->db->query("SELECT r.review_id,r.order_id,r.rating,r.text,r.date_added,c.firstname FROM `" . DB_PREFIX . "c2c_review` r JOIN `" . DB_PREFIX . "order` o ON o.order_id=r.order_id AND o.customer_id=r.customer_id JOIN `" . DB_PREFIX . "customer` c ON c.customer_id=r.customer_id JOIN `" . DB_PREFIX . "c2c_seller` s ON s.seller_id=r.seller_id WHERE r.seller_id=" . (int)$seller_id . " AND r.status=1 AND r.rating BETWEEN 1 AND 5 AND s.status='approved' AND s.customer_id<>r.customer_id AND c.status=1 AND c.store_id=0 AND o.store_id=0 AND o.order_status_id IN(" . $this->completeStatuses() . ") AND EXISTS(SELECT 1 FROM `" . DB_PREFIX . "c2c_order_item` i WHERE i.order_id=o.order_id AND i.seller_id=r.seller_id) AND NOT EXISTS(SELECT 1 FROM `" . DB_PREFIX . "customer_approval` ca WHERE ca.customer_id=c.customer_id AND ca.type='customer') ORDER BY r.review_id DESC")->rows;
    }

    private function reviewableOrder($seller_id,$customer_id,$order_id) {
        $row = $this->db->query("SELECT o.order_id FROM `" . DB_PREFIX . "order` o WHERE o.order_id=" . (int)$order_id . " AND o.customer_id=" . (int)$customer_id . " AND o.store_id=0 AND o.order_status_id IN(" . $this->completeStatuses() . ") AND EXISTS(SELECT 1 FROM `" . DB_PREFIX . "c2c_order_item` i WHERE i.order_id=o.order_id AND i.seller_id=" . (int)$seller_id . ") LIMIT 1")->row;
        return $row && $this->marketplace->isOrderSnapshotCurrent($order_id);
    }

    private function customer($customer_id) {
        $row = $this->db->query("SELECT customer_id FROM `" . DB_PREFIX . "customer` c WHERE c.customer_id=" . (int)$customer_id . " AND c.status=1 AND c.store_id=0 AND NOT EXISTS(SELECT 1 FROM `" . DB_PREFIX . "customer_approval` ca WHERE ca.customer_id=c.customer_id AND ca.type='customer') LIMIT 1")->row;
        if (!$row) throw new \InvalidArgumentException('Aktif ve onaylı müşteri oturumu gerekli.');
    }

    private function seller($seller_id) {
        $seller = $this->marketplace->getSeller($seller_id);
        if (!$seller || $seller['status'] !== 'approved') throw new \InvalidArgumentException('Onaylı mağaza bulunamadı.');
        return $seller;
    }

    private function requireEnabled() {
        if (!$this->marketplace->isEnabled()) throw new \RuntimeException('Pazaryeri şu anda etkin değil.');
    }

    private function completeStatuses() {
        $statuses = $this->config->get('config_complete_status');
        $statuses = is_array($statuses) ? array_filter(array_unique(array_map('intval',$statuses)), function($id){return $id>0;}) : array();
        return $statuses ? implode(',',$statuses) : '-1';
    }

    private function text($value,$min,$max,$label) {
        if (!is_scalar($value)) throw new \InvalidArgumentException($label . ' geçersiz.');
        $value = trim(strip_tags(html_entity_decode((string)$value,ENT_QUOTES|ENT_HTML5,'UTF-8')));
        if (!preg_match('//u',$value) || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/',$value)) throw new \InvalidArgumentException($label . ' geçersiz karakter içeriyor.');
        $length = function_exists('mb_strlen') ? mb_strlen($value,'UTF-8') : preg_match_all('/./us',$value);
        if ($length<$min || $length>$max) throw new \InvalidArgumentException($label . ' ' . $min . '–' . $max . ' karakter olmalı.');
        return $value;
    }

    private function q($value) {return "'" . $this->db->escape((string)$value) . "'";}
    private function lock($suffix) {
        // Identical name convention to Marketplace so product/store questions
        // share one customer rate-limit lock.
        $name = 'c2c_' . substr(hash('sha256', DB_PREFIX . $suffix),0,58);
        $row = $this->db->query('SELECT GET_LOCK(' . $this->q($name) . ',5) AS acquired')->row;
        if (!isset($row['acquired']) || (int)$row['acquired']!==1) throw new \RuntimeException('İşlem şu anda meşgul. Lütfen tekrar deneyin.');
        return $name;
    }
    private function unlock($name) {$this->db->query('SELECT RELEASE_LOCK(' . $this->q($name) . ')');}
}
