<?php
$_['heading_title'] = 'C2C Seller Campaigns';
