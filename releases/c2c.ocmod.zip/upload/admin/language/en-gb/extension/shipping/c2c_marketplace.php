<?php
$_['heading_title'] = 'C2C Store-based Shipping';
