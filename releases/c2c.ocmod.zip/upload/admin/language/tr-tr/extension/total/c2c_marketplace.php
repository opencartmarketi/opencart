<?php
$_['heading_title'] = 'C2C Mağaza Kampanyaları';
