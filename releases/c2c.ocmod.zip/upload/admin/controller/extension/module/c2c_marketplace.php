<?php
/** C2C Marketplace admin. OpenCart 3.0.5.1. No destructive uninstall. */
class ControllerExtensionModuleC2cMarketplace extends Controller {
    private $route = 'extension/module/c2c_marketplace';
    private $settingCode = 'module_c2c_marketplace';
    private $eventCode = 'c2c_marketplace';
    private $pageSize = 30;

    public function index() {
        $this->load->language($this->route);
        if (!$this->authorized('access', $this->route)) {
            return $this->deny();
        }
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('setting/setting');
        $this->load->library('c2c/marketplace');
        if (empty($this->session->data['c2c_admin_csrf'])) {
            $this->session->data['c2c_admin_csrf'] = bin2hex(random_bytes(32));
        }
        $section = $this->scalar($this->request->get, 'section', 'settings');
        if (!in_array($section, array('settings', 'sellers', 'products', 'settlements'), true)) {
            $section = 'settings';
        }
        $error = '';
        $settings = $this->model_setting_setting->getSetting($this->settingCode, 0);
        if ($this->isPost()) {
            try {
                $this->validateWrite();
                $operation = $this->scalar($this->request->post, 'operation');
                if ($operation === 'settings') {
                    $values = $this->validatedSettings();
                    $commerce = $this->validatedCommerceSettings();
                    if (!$values['module_c2c_marketplace_status']) {
                        $this->marketplace->pauseInventory();
                    }
                    $this->model_setting_setting->editSetting($this->settingCode, $values, 0);
                    foreach ($commerce as $code => $fields) {
                        $this->model_setting_setting->editSetting($code, $fields, 0);
                    }
                    // Recheck inventory after persisting the disabled flag to close
                    // a concurrent approval between the first pause and this save.
                    if (!$values['module_c2c_marketplace_status']) {
                        $this->marketplace->pauseInventory();
                    }
                    foreach ($values as $key => $value) {
                        $this->config->set($key, $value);
                    }
                    $section = 'settings';
                } elseif ($operation === 'seller') {
                    $status = $this->scalar($this->request->post, 'status');
                    if (!in_array($status, array('pending', 'approved', 'suspended'), true)) {
                        throw new InvalidArgumentException($this->language->get('error_status'));
                    }
                    $this->marketplace->setSellerStatus($this->positiveId($this->request->post, 'seller_id'), $status);
                    $section = 'sellers';
                } elseif ($operation === 'product') {
                    $approval = $this->scalar($this->request->post, 'approval');
                    if (!in_array($approval, array('approved', 'rejected', 'pending'), true)) {
                        throw new InvalidArgumentException($this->language->get('error_status'));
                    }
                    $this->marketplace->approveProduct($this->positiveId($this->request->post, 'product_id'), $approval);
                    $section = 'products';
                } elseif ($operation === 'settlement') {
                    $seller_id = $this->positiveId($this->request->post, 'seller_id');
                    $amount = $this->scalar($this->request->post, 'amount');
                    $reference = trim($this->scalar($this->request->post, 'reference'));
                    $referenceText = html_entity_decode($reference, ENT_QUOTES, 'UTF-8');
                    if (!preg_match('/^[0-9]{1,10}(\.[0-9]{1,2})?$/D', $amount) || (float)$amount <= 0) {
                        throw new InvalidArgumentException($this->language->get('error_amount'));
                    }
                    if (utf8_strlen($referenceText) < 3 || utf8_strlen($referenceText) > 128 || preg_match('/[\x00-\x1F\x7F]/', $referenceText)) {
                        throw new InvalidArgumentException($this->language->get('error_reference'));
                    }
                    $this->marketplace->addSettlement($seller_id, $amount, $reference, $this->user->getId());
                    $section = 'settlements';
                } else {
                    throw new InvalidArgumentException($this->language->get('error_operation'));
                }
                $this->session->data['c2c_admin_success'] = $this->language->get('text_success');
                $args = array('section' => $section);
                if ($operation === 'settlement') {
                    $args['seller_id'] = $seller_id;
                }
                $this->response->redirect($this->link($args));
                return;
            } catch (InvalidArgumentException $e) {
                $error = $e->getMessage();
            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Exception $e) {
                $this->log->write('C2C admin: operation failed (' . get_class($e) . ').');
                $error = $this->language->get('error_unavailable');
            }
        }
        $data = $this->load->language($this->route);
        $data['heading_title'] = $this->language->get('heading_title');
        $data['section'] = $section;
        $data['user_token'] = $this->session->data['user_token'];
        $data['csrf'] = $this->session->data['c2c_admin_csrf'];
        $data['error_warning'] = $error;
        $data['success'] = isset($this->session->data['c2c_admin_success']) ? $this->session->data['c2c_admin_success'] : '';
        unset($this->session->data['c2c_admin_success']);
        $data['action'] = $this->link(array('section' => $section));
        $data['cancel'] = $this->rawUrl($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
        $data['tabs'] = array();
        foreach (array('settings', 'sellers', 'products', 'settlements') as $tab) {
            $data['tabs'][] = array('id' => $tab, 'label' => $this->language->get('tab_' . $tab), 'href' => $this->link(array('section' => $tab)));
        }
        $data['breadcrumbs'] = array(
            array('text' => $this->language->get('text_home'), 'href' => $this->rawUrl($this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true))),
            array('text' => $this->language->get('text_extension'), 'href' => $data['cancel']),
            array('text' => $data['heading_title'], 'href' => $this->link())
        );
        $defaults = array('module_c2c_marketplace_status' => 0, 'module_c2c_marketplace_commission' => '10.00', 'module_c2c_marketplace_partner_host' => '', 'module_c2c_marketplace_brand' => 'Pazar Yeri');
        foreach ($defaults as $key => $value) {
            $data[$key] = isset($settings[$key]) ? $settings[$key] : $value;
            if ($this->isPost() && $this->scalar($this->request->post, 'operation') === 'settings' && isset($this->request->post[$key]) && is_scalar($this->request->post[$key])) {
                $data[$key] = html_entity_decode((string)$this->request->post[$key], ENT_QUOTES, 'UTF-8');
            }
        }
        foreach (array('total_c2c_marketplace_status' => 1, 'shipping_c2c_marketplace_status' => 0, 'shipping_c2c_marketplace_cost' => '30.00') as $key => $default) {
            $data[$key] = $this->config->get($key) !== null ? $this->config->get($key) : $default;
            if ($this->isPost() && isset($this->request->post[$key]) && is_scalar($this->request->post[$key])) {
                $data[$key] = (string)$this->request->post[$key];
            }
        }
        $data['base_currency'] = (string)$this->config->get('config_currency');
        $data['can_modify'] = $this->user->hasPermission('modify', $this->route);
        $data['sellers'] = array();
        $data['products'] = array();
        $data['settlements'] = array();
        $data['selected_seller'] = array();
        $data['selected_stats'] = array();
        $data['previous'] = '';
        $data['next'] = '';
        $page = $this->page();
        $data['page'] = $page;
        $data['seller_filter'] = $this->scalar($this->request->get, 'seller_status');
        if (!in_array($data['seller_filter'], array('', 'pending', 'approved', 'suspended'), true)) {
            $data['seller_filter'] = '';
        }
        $data['filter_links'] = array();
        foreach (array('' => 'text_all', 'pending' => 'status_pending', 'approved' => 'status_approved', 'suspended' => 'status_suspended') as $value => $label) {
            $data['filter_links'][] = array('value' => $value, 'label' => $this->language->get($label), 'href' => $this->link(array('section' => 'sellers', 'seller_status' => $value)));
        }
        $hasMore = false;
        try {
            if ($section === 'sellers') {
                $rows = $this->marketplace->getSellers($data['seller_filter'], ($page - 1) * $this->pageSize, $this->pageSize + 1);
                $hasMore = count($rows) > $this->pageSize;
                foreach (array_slice($rows, 0, $this->pageSize) as $row) {
                    $row['status_label'] = $this->language->get('status_' . $row['status']);
                    $row['finance_href'] = $this->link(array('section' => 'settlements', 'seller_id' => (int)$row['seller_id']));
                    $data['sellers'][] = $row;
                }
            } elseif ($section === 'products') {
                $rows = $this->marketplace->getModerationProducts(($page - 1) * $this->pageSize, $this->pageSize + 1);
                $hasMore = count($rows) > $this->pageSize;
                foreach (array_slice($rows, 0, $this->pageSize) as $row) {
                    if (!isset($row['store_name'])) {
                        $seller = $this->marketplace->getSeller((int)$row['seller_id']);
                        $row['store_name'] = $seller ? $seller['store_name'] : '';
                    }
                    $row['formatted_price'] = $this->money(isset($row['price']) ? $row['price'] : 0);
                    $row['approval_label'] = $this->language->get('status_' . $row['approval']);
                    $row['edit_href'] = $this->rawUrl($this->url->link('catalog/product/edit', 'user_token=' . $this->session->data['user_token'] . '&product_id=' . (int)$row['product_id'], true));
                    $data['products'][] = $row;
                }
            } elseif ($section === 'settlements') {
                $rows = $this->marketplace->getSettlements(($page - 1) * $this->pageSize, $this->pageSize + 1);
                $hasMore = count($rows) > $this->pageSize;
                foreach (array_slice($rows, 0, $this->pageSize) as $row) {
                    $row['formatted_amount'] = $this->money($row['amount'], isset($row['currency_code']) ? $row['currency_code'] : null);
                    $data['settlements'][] = $row;
                }
                $seller_id = $this->scalar($this->request->get, 'seller_id');
                if (ctype_digit($seller_id) && (int)$seller_id > 0) {
                    $data['selected_seller'] = $this->marketplace->getSeller((int)$seller_id);
                    if ($data['selected_seller']) {
                        $stats = $this->marketplace->getStats((int)$seller_id);
                        foreach (array('gross', 'commission', 'net', 'eligible_net', 'paid', 'balance') as $key) {
                            $stats[$key . '_formatted'] = $this->money(isset($stats[$key]) ? $stats[$key] : 0);
                        }
                        $data['selected_stats'] = $stats;
                    }
                }
            }
        } catch (Exception $e) {
            $this->log->write('C2C admin: listing failed (' . get_class($e) . ').');
            $data['error_warning'] = $this->language->get('error_unavailable');
        }
        $pageArgs = array('section' => $section, 'seller_status' => $data['seller_filter']);
        if ($data['selected_seller']) {
            $pageArgs['seller_id'] = (int)$data['selected_seller']['seller_id'];
        }
        if ($page > 1) {
            $data['previous'] = $this->link(array_merge($pageArgs, array('page' => $page - 1)));
        }
        if ($hasMore) {
            $data['next'] = $this->link(array_merge($pageArgs, array('page' => $page + 1)));
        }
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view($this->route, $data));
    }

    /** OpenCart 3 calls lifecycle hooks from token-protected native GET routes. */
    public function install() {
        if (!$this->lifecycleAuthorized('install')) {
            $this->deny();
            return;
        }
        $this->load->library('c2c/marketplace');
        $this->marketplace->install();
        $this->load->model('setting/setting');
        $settings = $this->model_setting_setting->getSetting($this->settingCode, 0);
        $defaults = array('module_c2c_marketplace_status' => 0, 'module_c2c_marketplace_commission' => '10.00', 'module_c2c_marketplace_partner_host' => '', 'module_c2c_marketplace_brand' => 'Pazar Yeri');
        $changed = false;
        foreach ($defaults as $key => $value) {
            if (!array_key_exists($key, $settings)) {
                $settings[$key] = $value;
                $changed = true;
            }
        }
        if ($changed) {
            $this->model_setting_setting->editSetting($this->settingCode, $settings, 0);
        }
        $this->load->model('setting/extension');
        $this->load->model('user/user_group');
        foreach (array('total', 'shipping') as $type) {
            $this->model_setting_extension->install($type, 'c2c_marketplace');
            foreach (array('access', 'modify') as $permission) {
                $this->model_user_user_group->addPermission($this->user->getGroupId(), $permission, 'extension/' . $type . '/c2c_marketplace');
            }
        }
        foreach (array('total_c2c_marketplace' => array('total_c2c_marketplace_status' => 1, 'total_c2c_marketplace_sort_order' => 4), 'shipping_c2c_marketplace' => array('shipping_c2c_marketplace_status' => 0, 'shipping_c2c_marketplace_cost' => '30.00', 'shipping_c2c_marketplace_sort_order' => 1)) as $code => $fields) {
            $existing = $this->model_setting_setting->getSetting($code, 0);
            $this->model_setting_setting->editSetting($code, array_merge($fields, $existing), 0);
        }
        $this->load->model('setting/event');
        $this->model_setting_event->deleteEventByCode($this->eventCode);
        $events = array(
            'catalog/view/product/product/before' => 'productBefore',
            'catalog/view/common/header/before' => 'headerBefore',
            'catalog/model/checkout/order/addOrder/after' => 'orderAfter',
            'catalog/model/checkout/order/addOrderHistory/after' => 'historyAfter',
            'catalog/controller/common/home/before' => 'partnerBefore'
        );
        foreach ($events as $trigger => $method) {
            $this->model_setting_event->addEvent($this->eventCode, $trigger, $this->route . '/' . $method, 1, 0);
        }
    }

    public function uninstall() {
        if (!$this->lifecycleAuthorized('uninstall')) {
            $this->deny();
            return;
        }
        $this->load->library('c2c/marketplace');
        $this->marketplace->pauseInventory();
        $this->load->model('setting/event');
        $this->model_setting_event->deleteEventByCode($this->eventCode);
        $this->load->model('setting/setting');
        $settings = $this->model_setting_setting->getSetting($this->settingCode, 0);
        $settings['module_c2c_marketplace_status'] = 0;
        $this->model_setting_setting->editSetting($this->settingCode, $settings, 0);
        $this->load->library('c2c/marketplace');
        $this->marketplace->uninstall();
    }

    private function lifecycleAuthorized($method) {
        if (!$this->validUserToken() || !$this->user->isLogged()) {
            return false;
        }
        // Do not expose independently callable lifecycle GET endpoints.
        return $this->scalar($this->request->get, 'route') === 'extension/extension/module/' . $method
            && $this->scalar($this->request->get, 'extension') === 'c2c_marketplace'
            && $this->user->hasPermission('modify', 'extension/extension/module');
    }

    private function validateWrite() {
        if (!$this->isPost() || !$this->authorized('modify', $this->route)) {
            throw new InvalidArgumentException($this->language->get('error_permission'));
        }
        $submitted = $this->scalar($this->request->post, 'csrf');
        $expected = isset($this->session->data['c2c_admin_csrf']) ? $this->session->data['c2c_admin_csrf'] : '';
        if (!$expected || !$submitted || !hash_equals($expected, $submitted)) {
            throw new InvalidArgumentException($this->language->get('error_csrf'));
        }
    }

    private function validatedSettings() {
        foreach (array('module_c2c_marketplace_status', 'module_c2c_marketplace_commission', 'module_c2c_marketplace_partner_host', 'module_c2c_marketplace_brand') as $field) {
            if (!isset($this->request->post[$field]) || !is_scalar($this->request->post[$field])) {
                throw new InvalidArgumentException($this->language->get('error_operation'));
            }
        }
        $status = $this->scalar($this->request->post, 'module_c2c_marketplace_status');
        $commission = trim($this->scalar($this->request->post, 'module_c2c_marketplace_commission'));
        $host = strtolower(trim($this->scalar($this->request->post, 'module_c2c_marketplace_partner_host')));
        $brand = trim(html_entity_decode($this->scalar($this->request->post, 'module_c2c_marketplace_brand'), ENT_QUOTES, 'UTF-8'));
        if (!in_array($status, array('0', '1'), true)) {
            throw new InvalidArgumentException($this->language->get('error_status'));
        }
        if (!preg_match('/^[0-9]{1,3}(\.[0-9]{1,2})?$/D', $commission) || (float)$commission < 0 || (float)$commission > 100) {
            throw new InvalidArgumentException($this->language->get('error_commission'));
        }
        if ($host !== '') {
            if (strlen($host) > 253 || strpos($host, '.') === false || filter_var($host, FILTER_VALIDATE_IP)) {
                throw new InvalidArgumentException($this->language->get('error_host'));
            }
            foreach (explode('.', $host) as $label) {
                if (!preg_match('/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/D', $label)) {
                    throw new InvalidArgumentException($this->language->get('error_host'));
                }
            }
            $primaryHost = defined('HTTP_CATALOG') ? strtolower((string)parse_url(HTTP_CATALOG, PHP_URL_HOST)) : '';
            if ($host === $primaryHost) {
                throw new InvalidArgumentException($this->language->get('error_host_primary'));
            }
        }
        if (utf8_strlen($brand) < 2 || utf8_strlen($brand) > 60 || preg_match('/[\x00-\x1F\x7F]/', $brand)) {
            throw new InvalidArgumentException($this->language->get('error_brand'));
        }
        return array(
            'module_c2c_marketplace_status' => (int)$status,
            'module_c2c_marketplace_commission' => number_format((float)$commission, 2, '.', ''),
            'module_c2c_marketplace_partner_host' => $host,
            'module_c2c_marketplace_brand' => $brand
        );
    }

    private function validatedCommerceSettings() {
        $values = array();
        foreach (array('total_c2c_marketplace_status' => 1, 'shipping_c2c_marketplace_status' => 0) as $key => $default) {
            $value = $this->config->get($key) !== null ? (string)$this->config->get($key) : (string)$default;
            if (array_key_exists($key, $this->request->post)) {
                if (!is_scalar($this->request->post[$key])) throw new InvalidArgumentException($this->language->get('error_status'));
                $value = (string)$this->request->post[$key];
            }
            if (!in_array($value, array('0', '1'), true)) throw new InvalidArgumentException($this->language->get('error_status'));
            $values[$key] = (int)$value;
        }
        $cost = $this->config->get('shipping_c2c_marketplace_cost') !== null ? (string)$this->config->get('shipping_c2c_marketplace_cost') : '30.00';
        if (array_key_exists('shipping_c2c_marketplace_cost', $this->request->post)) {
            if (!is_scalar($this->request->post['shipping_c2c_marketplace_cost'])) throw new InvalidArgumentException($this->language->get('error_shipping_cost'));
            $cost = (string)$this->request->post['shipping_c2c_marketplace_cost'];
        }
        if (!preg_match('/^[0-9]{1,8}(\.[0-9]{1,2})?$/D', $cost)) throw new InvalidArgumentException($this->language->get('error_shipping_cost'));
        return array(
            'total_c2c_marketplace' => array('total_c2c_marketplace_status' => $values['total_c2c_marketplace_status'], 'total_c2c_marketplace_sort_order' => 4),
            'shipping_c2c_marketplace' => array('shipping_c2c_marketplace_status' => $values['shipping_c2c_marketplace_status'], 'shipping_c2c_marketplace_cost' => number_format((float)$cost, 2, '.', ''), 'shipping_c2c_marketplace_sort_order' => 1)
        );
    }

    private function validUserToken() {
        $token = $this->scalar($this->request->get, 'user_token');
        $expected = isset($this->session->data['user_token']) && is_string($this->session->data['user_token']) ? $this->session->data['user_token'] : '';
        return $token !== '' && $expected !== '' && hash_equals($expected, $token);
    }

    private function authorized($permission, $route) {
        return $this->user->isLogged() && $this->validUserToken() && $this->user->hasPermission($permission, $route);
    }

    private function deny() {
        $this->response->addHeader('HTTP/1.1 403 Forbidden');
        $this->response->setOutput('C2C: Access denied.');
    }

    private function isPost() {
        return isset($this->request->server['REQUEST_METHOD']) && $this->request->server['REQUEST_METHOD'] === 'POST';
    }

    private function scalar($source, $name, $default = '') {
        return isset($source[$name]) && is_scalar($source[$name]) ? (string)$source[$name] : $default;
    }

    private function positiveId($source, $name) {
        $value = $this->scalar($source, $name);
        if (!ctype_digit($value) || (int)$value < 1 || strlen($value) > 10) {
            throw new InvalidArgumentException($this->language->get('error_id'));
        }
        return (int)$value;
    }

    private function page() {
        $value = $this->scalar($this->request->get, 'page', '1');
        return ctype_digit($value) ? min(100000, max(1, (int)$value)) : 1;
    }

    private function link($args = array()) {
        $args = array_merge(array('user_token' => $this->session->data['user_token']), $args);
        return $this->rawUrl($this->url->link($this->route, http_build_query($args, '', '&'), true));
    }

    private function rawUrl($url) {
        return str_replace('&amp;', '&', $url);
    }

    private function money($value, $currency_code = null) {
        $currency_code = $currency_code ? $currency_code : $this->config->get('config_currency');
        return html_entity_decode($this->currency->format((float)$value, $currency_code, 1), ENT_QUOTES, 'UTF-8');
    }
}
