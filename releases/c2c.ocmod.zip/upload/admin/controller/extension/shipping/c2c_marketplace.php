<?php
/** Configuration is centralized in the token-protected Marketplace module. */
class ControllerExtensionShippingC2cMarketplace extends Controller {
    public function index() {
        $this->response->redirect($this->url->link('extension/module/c2c_marketplace', 'user_token=' . $this->session->data['user_token'], true));
    }
}
